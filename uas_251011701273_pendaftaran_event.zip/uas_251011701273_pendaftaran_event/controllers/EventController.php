<?php
 // (("Class EventController Mengelola alur CRUD untuk data Event."))
class EventController {
    private $authModel;
    private $eventModel;

    public function __construct($authModel, $eventModel) {
        $this->authModel = $authModel;
        $this->eventModel = $eventModel;
    }

     // (("Tampilan List Event (Read, Search, Pagination, Filter, Sorting)"))
    public function index() {
        $this->authModel->checkSession();

        // (("Parameter dari Query String"))
        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? '');
        $sort_by = trim($_GET['sort_by'] ?? 'date');
        $sort_order = trim($_GET['sort_order'] ?? 'ASC');
        
        // (("Paginasi"))
        $page = (int)($_GET['page'] ?? 1);
        if ($page < 1) $page = 1;
        $limit = 5; // Batasan 5 per halaman agar paginasi berfungsi dengan baik
        $offset = ($page - 1) * $limit;

        // (("Ambil Data"))
        $events = $this->eventModel->getAll($search, $status, $sort_by, $sort_order, $limit, $offset);
        $totalItems = $this->eventModel->countAll($search, $status);
        $totalPages = ceil($totalItems / $limit);

        $user = $this->authModel->getLoggedInUser();

        // (("Tampilkan view"))
        include "views/events/index.php";
    }

     // (("Form Tambah dan Aksi Create Event"))
    public function add() {
        $this->authModel->checkSession();

        $error = "";
        $success = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $location = trim($_POST['location'] ?? '');
            $date = trim($_POST['date'] ?? '');
            $time = trim($_POST['time'] ?? '');
            $quota = trim($_POST['quota'] ?? '');
            $price = trim($_POST['price'] ?? '0');
            $status = trim($_POST['status'] ?? 'Active');

            // (("Validasi Server Side"))
            if (empty($name) || empty($location) || empty($date) || empty($time) || empty($quota) || $price === '') {
                $error = "Semua kolom wajib diisi!";
            } elseif (!is_numeric($quota) || intval($quota) <= 0) {
                $error = "Kuota harus berupa angka positif!";
            } elseif (!is_numeric($price) || intval($price) < 0) {
                $error = "Harga harus berupa angka positif atau 0!";
            } else {
                // (("Simpan ke database"))
                if ($this->eventModel->create($name, $location, $date, $time, intval($quota), intval($price), $status)) {
                    $_SESSION['success_msg'] = "Event berhasil ditambahkan!";
                    header("Location: index.php?action=events");
                    exit();
                } else {
                    $error = "Terjadi kesalahan saat menyimpan event!";
                }
            }
        }

        $user = $this->authModel->getLoggedInUser();
        include "views/events/add.php";
    }

     // (("Form Edit dan Aksi Update Event"))
    public function edit() {
        $this->authModel->checkSession();

        $id = (int)($_GET['id'] ?? 0);
        $event = $this->eventModel->findById($id);

        if (!$event) {
            $_SESSION['error_msg'] = "Event tidak ditemukan!";
            header("Location: index.php?action=events");
            exit();
        }

        $error = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $location = trim($_POST['location'] ?? '');
            $date = trim($_POST['date'] ?? '');
            $time = trim($_POST['time'] ?? '');
            $quota = trim($_POST['quota'] ?? '');
            $price = trim($_POST['price'] ?? '0');
            $status = trim($_POST['status'] ?? 'Active');

            // (("Validasi"))
            if (empty($name) || empty($location) || empty($date) || empty($time) || empty($quota) || $price === '') {
                $error = "Semua kolom wajib diisi!";
            } elseif (!is_numeric($quota) || intval($quota) <= 0) {
                $error = "Kuota harus berupa angka positif!";
            } elseif (!is_numeric($price) || intval($price) < 0) {
                $error = "Harga harus berupa angka positif atau 0!";
            } else {
                // (("Update ke database"))
                if ($this->eventModel->update($id, $name, $location, $date, $time, intval($quota), intval($price), $status)) {
                    $_SESSION['success_msg'] = "Event berhasil diperbarui!";
                    header("Location: index.php?action=events");
                    exit();
                } else {
                    $error = "Terjadi kesalahan saat memperbarui event!";
                }
            }
        }

        $user = $this->authModel->getLoggedInUser();
        include "views/events/edit.php";
    }

     // (("Aksi Hapus Event (Delete)"))
    public function delete() {
        $this->authModel->checkSession();

        $id = (int)($_GET['id'] ?? 0);
        
        if ($this->eventModel->delete($id)) {
            $_SESSION['success_msg'] = "Event berhasil dihapus!";
        } else {
            $_SESSION['error_msg'] = "Gagal menghapus event!";
        }

        header("Location: index.php?action=events");
        exit();
    }
}
