<?php
 // (("Class ReportController Mengelola pembuatan laporan data pendaftaran dalam format PDF, Excel, dan Cetak (Print)."))
class ReportController {
    private $authModel;
    private $reportModel;
    private $eventModel;

    public function __construct($authModel, $reportModel, $eventModel) {
        $this->authModel = $authModel;
        $this->reportModel = $reportModel;
        $this->eventModel = $eventModel;
    }

     // (("Menampilkan Halaman Laporan Utama dengan Filter dan Preview"))
    public function index() {
        $this->authModel->checkSession();

        // (("Parameter filter"))
        $event_id = trim($_GET['event_id'] ?? '');
        $date = trim($_GET['date'] ?? '');
        $payment_status = trim($_GET['payment_status'] ?? '');

        // (("Dapatkan data berfilter"))
        $reportData = $this->reportModel->getFilteredData($event_id, $date, $payment_status);

        // (("List event untuk dropdown"))
        $events = $this->eventModel->getDropdownList();

        $user = $this->authModel->getLoggedInUser();
        
        include "views/reports/index.php";
    }

     // (("Halaman Cetak Laporan (Print & Save as PDF)"))
    public function printReport() {
        $this->authModel->checkSession();

        $event_id = trim($_GET['event_id'] ?? '');
        $date = trim($_GET['date'] ?? '');
        $payment_status = trim($_GET['payment_status'] ?? '');
        $format = trim($_GET['format'] ?? 'print'); // 'print' atau 'pdf'

        $reportData = $this->reportModel->getFilteredData($event_id, $date, $payment_status);

        // (("Ambil info nama event jika difilter"))
        $eventNameFilter = "Semua Event";
        if (!empty($event_id)) {
            $event = $this->eventModel->findById($event_id);
            if ($event) {
                $eventNameFilter = $event['name'];
            }
        }

        include "views/reports/print.php";
    }

     // (("Aksi Export Laporan ke Excel (.xls)"))
    public function exportExcel() {
        $this->authModel->checkSession();

        $event_id = trim($_GET['event_id'] ?? '');
        $date = trim($_GET['date'] ?? '');
        $payment_status = trim($_GET['payment_status'] ?? '');

        $reportData = $this->reportModel->getFilteredData($event_id, $date, $payment_status);

        $eventNameFilter = "Semua Event";
        if (!empty($event_id)) {
            $event = $this->eventModel->findById($event_id);
            if ($event) {
                $eventNameFilter = $event['name'];
            }
        }

        // (("Set Headers untuk men-download file Excel (.xls)"))
        $filename = "Laporan_Pendaftaran_Event_" . date('Ymd_His') . ".xls";
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Pragma: no-cache");
        header("Expires: 0");

        // (("Render HTML Table khusus untuk Excel"))
        include "views/reports/excel.php";
        exit();
    }
}
