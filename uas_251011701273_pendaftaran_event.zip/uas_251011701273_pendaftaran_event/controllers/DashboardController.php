<?php
 // (("Class DashboardController Mengelola pemrosesan data statistik untuk dashboard administrator."))
class DashboardController {
    private $authModel;
    private $eventModel;
    private $participantModel;

    public function __construct($authModel, $eventModel, $participantModel) {
        $this->authModel = $authModel;
        $this->eventModel = $eventModel;
        $this->participantModel = $participantModel;
    }

     // (("Menampilkan Halaman Dashboard Utama"))
    public function index() {
        // (("Proteksi Halaman"))
        $this->authModel->checkSession();

        // (("Ambil data statistik dari model"))
        $totalEvents = $this->eventModel->getTotalEvents();
        $totalParticipants = $this->participantModel->getTotalParticipants();
        $activeEvents = $this->eventModel->getActiveEventCount();
        $completedEvents = $this->eventModel->getCompletedEventCount();
        $totalPayments = $this->participantModel->getTotalPayments();

        // (("Ambil data list untuk dashboard"))
        $upcomingEvents = $this->eventModel->getUpcomingEvents(5);
        $recentActivity = $this->participantModel->getRecentActivity(5);
        
        // (("Ambil data untuk grafik"))
        $chartData = $this->participantModel->getRegistrationChartData();

        // (("Menyimpan data login user"))
        $user = $this->authModel->getLoggedInUser();

        // (("Tampilkan view dashboard"))
        include "views/dashboard.php";
    }
}
