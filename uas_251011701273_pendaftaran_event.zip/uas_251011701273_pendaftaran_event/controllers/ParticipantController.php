<?php
 // (("Class ParticipantController Mengelola alur CRUD data peserta dan proses upload bukti pembayaran."))
class ParticipantController {
    private $authModel;
    private $participantModel;
    private $eventModel;
    private $uploadHelper;

    public function __construct($authModel, $participantModel, $eventModel, $uploadHelper) {
        $this->authModel = $authModel;
        $this->participantModel = $participantModel;
        $this->eventModel = $eventModel;
        $this->uploadHelper = $uploadHelper;
    }

     // (("Tampilan List Peserta (Read, Search, Pagination, Filter, Sorting)"))
    public function index() {
        $this->authModel->checkSession();

        // (("Parameter"))
        $search = trim($_GET['search'] ?? '');
        $event_id = trim($_GET['event_id'] ?? '');
        $payment_status = trim($_GET['payment_status'] ?? '');
        $sort_by = trim($_GET['sort_by'] ?? 'registration_date');
        $sort_order = trim($_GET['sort_order'] ?? 'DESC');

        // (("Paginasi"))
        $page = (int)($_GET['page'] ?? 1);
        if ($page < 1) $page = 1;
        $limit = 5; // Batasan 5 per halaman agar paginasi terlihat berfungsi
        $offset = ($page - 1) * $limit;

        // (("Ambil Data"))
        $participants = $this->participantModel->getAll($search, $event_id, $payment_status, $sort_by, $sort_order, $limit, $offset);
        $totalItems = $this->participantModel->countAll($search, $event_id, $payment_status);
        $totalPages = ceil($totalItems / $limit);

        // (("List event untuk filter dropdown"))
        $events = $this->eventModel->getDropdownList();
        
        $user = $this->authModel->getLoggedInUser();

        include "views/participants/index.php";
    }

     // (("Halaman Detail Peserta"))
    public function detail() {
        $this->authModel->checkSession();

        $id = $_GET['id'] ?? '';
        $participant = $this->participantModel->findById($id);

        if (!$participant) {
            $_SESSION['error_msg'] = "Peserta tidak ditemukan!";
            header("Location: index.php?action=participants");
            exit();
        }

        $user = $this->authModel->getLoggedInUser();
        include "views/participants/detail.php";
    }

     // (("Aksi Tambah Peserta (Create)"))
    public function add() {
        $this->authModel->checkSession();

        $error = "";
        $success = "";
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = trim($_POST['id'] ?? '');
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $gender = trim($_POST['gender'] ?? '');
            $event_id = trim($_POST['event_id'] ?? '');
            $registration_date = trim($_POST['registration_date'] ?? '');
            $payment_status = trim($_POST['payment_status'] ?? 'Pending');
            $attendance_status = trim($_POST['attendance_status'] ?? 'Absent');

            // (("Validasi Server-side"))
            if (empty($id) || empty($name) || empty($email) || empty($phone) || empty($gender) || empty($event_id) || empty($registration_date)) {
                $error = "Semua kolom wajib diisi!";
            } elseif (!is_numeric($id)) {
                $error = "ID Peserta harus berupa angka (NIM)!";
            } elseif ($this->participantModel->isIdExists($id)) {
                $error = "ID Peserta / NIM sudah terdaftar!";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Format email tidak valid!";
            } elseif (!preg_match("/^[0-9]+$/", $phone)) {
                $error = "Nomor HP hanya boleh berisi angka!";
            } else {
                // (("Cek kuota event"))
                $event = $this->eventModel->findById($event_id);
                if (!$event) {
                    $error = "Event tidak valid!";
                } else {
                    // (("Hitung jumlah pendaftar saat ini di event tersebut"))
                    $current_participants = $this->participantModel->countAll('', $event_id, '');
                    if ($current_participants >= $event['quota']) {
                        $error = "Kuota Event '" . $event['name'] . "' sudah penuh! (Maksimal: " . $event['quota'] . ")";
                    } else {
                        // (("Proses Upload Bukti Pembayaran (Optional pada form tambah)"))
                        $filename = null;
                        $uploadSuccess = true;
                        
                        if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] === UPLOAD_ERR_OK) {
                            try {
                                $filename = $this->uploadHelper->uploadFile($_FILES['payment_proof'], 'bukti_' . $id . '_');
                            } catch (Exception $e) {
                                $error = $e->getMessage();
                                $uploadSuccess = false;
                            }
                        }

                        if ($uploadSuccess) {
                            if ($this->participantModel->create($id, $name, $email, $phone, $gender, $event_id, $registration_date, $payment_status, $filename, $attendance_status)) {
                                $_SESSION['success_msg'] = "Peserta berhasil ditambahkan!";
                                header("Location: index.php?action=participants");
                                exit();
                            } else {
                                // (("Hapus file yang baru saja diupload jika insert gagal"))
                                if ($filename) {
                                    $this->uploadHelper->deleteFile($filename);
                                }
                                $error = "Gagal menyimpan data peserta!";
                            }
                        }
                    }
                }
            }
        }

        $events = $this->eventModel->getDropdownList();
        $user = $this->authModel->getLoggedInUser();
        include "views/participants/add.php";
    }

     // (("Aksi Edit Peserta (Update)"))
    public function edit() {
        $this->authModel->checkSession();

        $id = $_GET['id'] ?? '';
        $participant = $this->participantModel->findById($id);

        if (!$participant) {
            $_SESSION['error_msg'] = "Peserta tidak ditemukan!";
            header("Location: index.php?action=participants");
            exit();
        }

        $error = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $gender = trim($_POST['gender'] ?? '');
            $event_id = trim($_POST['event_id'] ?? '');
            $registration_date = trim($_POST['registration_date'] ?? '');
            $payment_status = trim($_POST['payment_status'] ?? 'Pending');
            $attendance_status = trim($_POST['attendance_status'] ?? 'Absent');

            // (("Validasi"))
            if (empty($name) || empty($email) || empty($phone) || empty($gender) || empty($event_id) || empty($registration_date)) {
                $error = "Semua kolom wajib diisi!";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Format email tidak valid!";
            } elseif (!preg_match("/^[0-9]+$/", $phone)) {
                $error = "Nomor HP hanya boleh berisi angka!";
            } else {
                // (("Cek kuota jika event diganti"))
                $quotaCheck = true;
                if ($event_id != $participant['event_id']) {
                    $event = $this->eventModel->findById($event_id);
                    if ($event) {
                        $current_participants = $this->participantModel->countAll('', $event_id, '');
                        if ($current_participants >= $event['quota']) {
                            $error = "Kuota Event baru sudah penuh!";
                            $quotaCheck = false;
                        }
                    }
                }

                if ($quotaCheck) {
                    $filename = $participant['payment_proof'];
                    $uploadSuccess = true;

                    // (("Upload file baru jika ada"))
                    if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] === UPLOAD_ERR_OK) {
                        try {
                            // (("Upload file baru"))
                            $newFilename = $this->uploadHelper->uploadFile($_FILES['payment_proof'], 'bukti_' . $id . '_');
                            // (("Hapus file lama jika ada file baru dan berhasil"))
                            if (!empty($filename)) {
                                $this->uploadHelper->deleteFile($filename);
                            }
                            $filename = $newFilename;
                        } catch (Exception $e) {
                            $error = $e->getMessage();
                            $uploadSuccess = false;
                        }
                    }

                    if ($uploadSuccess) {
                        if ($this->participantModel->update($id, $name, $email, $phone, $gender, $event_id, $registration_date, $payment_status, $filename, $attendance_status)) {
                            $_SESSION['success_msg'] = "Peserta berhasil diperbarui!";
                            header("Location: index.php?action=participants");
                            exit();
                        } else {
                            $error = "Gagal memperbarui data peserta!";
                        }
                    }
                }
            }
        }

        $events = $this->eventModel->getDropdownList();
        $user = $this->authModel->getLoggedInUser();
        include "views/participants/edit.php";
    }

     // (("Halaman Upload Bukti Pembayaran Khusus"))
    public function upload_payment() {
        $this->authModel->checkSession();

        $id = $_GET['id'] ?? '';
        $participant = $this->participantModel->findById($id);

        if (!$participant) {
            $_SESSION['error_msg'] = "Peserta tidak ditemukan!";
            header("Location: index.php?action=participants");
            exit();
        }

        $error = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] === UPLOAD_ERR_OK) {
                try {
                    // (("Upload"))
                    $newFilename = $this->uploadHelper->uploadFile($_FILES['payment_proof'], 'bukti_' . $id . '_');
                    
                    // (("Hapus file lama"))
                    if (!empty($participant['payment_proof'])) {
                        $this->uploadHelper->deleteFile($participant['payment_proof']);
                    }

                    // (("Update status pembayaran otomatis jadi Lunas jika admin mengaturnya, atau tetap"))
                    $status = $_POST['payment_status'] ?? 'Paid'; // Default lunas jika upload bukti oleh admin

                    if ($this->participantModel->updatePaymentProof($id, $newFilename, $status)) {
                        $_SESSION['success_msg'] = "Bukti pembayaran berhasil diupload!";
                        header("Location: index.php?action=participant_detail&id=" . $id);
                        exit();
                    } else {
                        $error = "Gagal mengupdate database.";
                    }
                } catch (Exception $e) {
                    $error = $e->getMessage();
                }
            } else {
                $error = "Pilih file terlebih dahulu!";
            }
        }

        $user = $this->authModel->getLoggedInUser();
        include "views/participants/upload_payment.php";
    }

     // (("Aksi Hapus Peserta (Delete)"))
    public function delete() {
        $this->authModel->checkSession();

        $id = $_GET['id'] ?? '';
        $participant = $this->participantModel->findById($id);

        if ($participant) {
            // (("Hapus file bukti pembayaran dari folder uploads"))
            if (!empty($participant['payment_proof'])) {
                $this->uploadHelper->deleteFile($participant['payment_proof']);
            }

            if ($this->participantModel->delete($id)) {
                $_SESSION['success_msg'] = "Peserta berhasil dihapus!";
            } else {
                $_SESSION['error_msg'] = "Gagal menghapus peserta!";
            }
        } else {
            $_SESSION['error_msg'] = "Peserta tidak ditemukan!";
        }

        header("Location: index.php?action=participants");
        exit();
    }
}
