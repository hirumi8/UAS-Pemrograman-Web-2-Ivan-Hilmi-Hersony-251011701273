<?php
 // (("Class AuthController Mengontrol logika registrasi, login, logout, dan manajemen profil user."))
class AuthController {
    private $authModel;
    private $userModel;

    public function __construct($authModel, $userModel) {
        $this->authModel = $authModel;
        $this->userModel = $userModel;
    }

     // (("Menampilkan dan memproses Halaman Login"))
    public function login() {
        // (("Jika sudah login, langsung ke dashboard"))
        if ($this->authModel->isLoggedIn()) {
            header("Location: index.php?action=dashboard");
            exit();
        }

        $error = "";
        
        // (("Cek input POST"))
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = trim($_POST['password'] ?? '');

            $result = $this->authModel->login($username, $password);
            if ($result === true) {
                header("Location: index.php?action=dashboard");
                exit();
            } else {
                $error = $result;
            }
        }

        // (("Tampilkan view login"))
        include "views/auth/login.php";
    }

     // (("Menampilkan dan memproses Halaman Registrasi"))
    public function register() {
        if ($this->authModel->isLoggedIn()) {
            header("Location: index.php?action=dashboard");
            exit();
        }

        $error = "";
        $success = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');
            $confirm_password = trim($_POST['confirm_password'] ?? '');

            $result = $this->authModel->register($name, $username, $email, $password, $confirm_password);
            if ($result === true) {
                $success = "Registrasi berhasil! Silakan login menggunakan username baru Anda.";
            } else {
                $error = $result;
            }
        }

        include "views/auth/register.php";
    }

     // (("Menampilkan dan memproses Halaman Edit Profil"))
    public function profile() {
        // (("Proteksi Halaman"))
        $this->authModel->checkSession();

        $user_session = $this->authModel->getLoggedInUser();
        $user_id = $user_session['id'];
        
        $error = "";
        $success = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');
            $confirm_password = trim($_POST['confirm_password'] ?? '');

            // (("Validasi input"))
            if (empty($name) || empty($email)) {
                $error = "Nama dan email wajib diisi!";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Format email tidak valid!";
            } elseif (!empty($password) && strlen($password) < 6) {
                $error = "Password minimal 6 karakter!";
            } elseif (!empty($password) && $password !== $confirm_password) {
                $error = "Konfirmasi password tidak cocok!";
            } else {
                // (("Proses update"))
                $pass = !empty($password) ? $password : null;
                
                // (("Cek email ganda (kecuali milik sendiri)"))
                $existing = $this->userModel->findByEmail($email);
                if ($existing && $existing['id'] != $user_id) {
                    $error = "Email sudah digunakan oleh akun lain!";
                } else {
                    if ($this->userModel->updateProfile($user_id, $name, $email, $pass)) {
                        $success = "Profil berhasil diperbarui!";
                        // (("Update session data"))
                        $_SESSION['name'] = $name;
                        $_SESSION['email'] = $email;
                    } else {
                        $error = "Gagal memperbarui profil!";
                    }
                }
            }
        }

        // (("Ambil data user terupdate"))
        $user = $this->userModel->findById($user_id);
        
        include "views/auth/profile.php";
    }

     // (("Proses Logout"))
    public function logout() {
        $this->authModel->logout();
        header("Location: index.php?action=login");
        exit();
    }
}
