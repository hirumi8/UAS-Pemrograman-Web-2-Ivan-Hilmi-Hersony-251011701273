-- (("Database creation script"))
-- (("Database Name: db_uas_251011701273"))
-- (("Author: Ivan Hilmi Hersony (NIM: 251011701273)"))

CREATE DATABASE IF NOT EXISTS `db_uas_251011701273`;
USE `db_uas_251011701273`;

SET FOREIGN_KEY_CHECKS = 0;


-- (("1. Table: users"))
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (("2. Table: events"))
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `location` VARCHAR(150) NOT NULL,
  `date` DATE NOT NULL,
  `time` TIME NOT NULL,
  `quota` INT NOT NULL,
  `price` INT NOT NULL DEFAULT 0,
  `status` ENUM('Active', 'Completed', 'Cancelled') DEFAULT 'Active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (("3. Table: participants"))
DROP TABLE IF EXISTS `participants`;
CREATE TABLE `participants` (
  `id` BIGINT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `gender` ENUM('Laki-laki', 'Perempuan') NOT NULL,
  `event_id` INT NOT NULL,
  `registration_date` DATE NOT NULL,
  `payment_status` ENUM('Pending', 'Paid', 'Rejected') DEFAULT 'Pending',
  `payment_proof` VARCHAR(255) DEFAULT NULL,
  `attendance_status` ENUM('Absent', 'Present') DEFAULT 'Absent',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`event_id`) REFERENCES `events`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- (("--------------------------------------------------------"))
-- (("DUMMY DATA SEEDING"))
-- (("--------------------------------------------------------"))

-- (("Seed User (Username: ivanhilmi, Password: password123)"))
INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'Ivan Hilmi Hersony', 'ivanhilmi', 'ivan@student.ac.id', '$2y$10$52mX1vc.p6bHSjI0Ij.UU.rPKmz64MQmZbGAlOXH69vPTwlZaRuuy');

-- (("Seed Events (Minimal 5 records)"))
INSERT INTO `events` (`id`, `name`, `location`, `date`, `time`, `quota`, `price`, `status`) VALUES
(1, 'Web Development Seminar', 'Selasar Gedung A, Universitas Pamulang', '2026-07-15', '09:00:00', 100, 50000, 'Active'),
(2, 'AI & Machine Learning Workshop', 'Lab Komputer Ruang 405', '2026-07-20', '13:00:00', 50, 150000, 'Active'),
(3, 'UI/UX Design Boot Camp', 'Ruang Aula Utama Kampus 2', '2026-07-25', '08:00:00', 75, 100000, 'Active'),
(4, 'Cyber Security Conference', 'Hotel Grandhika, Jakarta', '2026-06-10', '10:00:00', 200, 250000, 'Completed'),
(5, 'Cloud Computing Meetup', 'Virtual Zoom Meeting', '2026-08-05', '19:00:00', 150, 0, 'Active');

-- (("Seed Participants (Minimal 5 records, first record must have ID: 251011701273)"))
INSERT INTO `participants` (`id`, `name`, `email`, `phone`, `gender`, `event_id`, `registration_date`, `payment_status`, `payment_proof`, `attendance_status`) VALUES
(251011701273, 'Ivan Hilmi Hersony', 'ivan@student.ac.id', '081234567890', 'Laki-laki', 1, '2026-07-02', 'Paid', 'bukti_251011701273.png', 'Present'),
(251011701274, 'Ahmad Rafli', 'ahmad@gmail.com', '082345678901', 'Laki-laki', 1, '2026-07-02', 'Pending', NULL, 'Absent'),
(251011701275, 'Siti Aminah', 'siti@gmail.com', '083456789012', 'Perempuan', 2, '2026-07-01', 'Paid', 'bukti_251011701275.png', 'Present'),
(251011701276, 'Budi Santoso', 'budi@gmail.com', '084567890123', 'Laki-laki', 3, '2026-06-29', 'Rejected', 'bukti_251011701276.png', 'Absent'),
(251011701277, 'Dewi Lestari', 'dewi@gmail.com', '085678901234', 'Perempuan', 4, '2026-06-09', 'Paid', 'bukti_251011701277.png', 'Present');

SET FOREIGN_KEY_CHECKS = 1;
