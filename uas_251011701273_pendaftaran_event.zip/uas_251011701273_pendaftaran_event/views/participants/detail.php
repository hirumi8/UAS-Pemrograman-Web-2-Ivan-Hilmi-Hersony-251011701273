<?php
// (("Include header layout"))
include "views/layout/header.php";

$proof = $participant['payment_proof'];
$isPdf = !empty($proof) && strtolower(pathinfo($proof, PATHINFO_EXTENSION)) === 'pdf';
$isImg = !empty($proof) && in_array(strtolower(pathinfo($proof, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png']);
?>

<div class="page-header">
    <div class="page-title">
        <h1>Detail Informasi Peserta</h1>
        <p>Lihat detail data pendaftaran, biodata, dan bukti pembayaran peserta</p>
    </div>
    <div>
        <a href="index.php?action=participants" class="btn btn-outline">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
</div>

<div class="card-container">
    <div class="card-title-bar">
        <h3><i class="fa-solid fa-address-card"></i> Informasi Peserta: <?= htmlspecialchars($participant['name']) ?></h3>
        <div class="action-buttons">
            <a href="index.php?action=participant_edit&id=<?= $participant['id'] ?>" class="btn btn-secondary" style="padding: 6px 15px; font-size: 13px;">
                <i class="fa-solid fa-user-pen"></i> Edit Peserta
            </a>
        </div>
    </div>

    <div class="detail-card">
        <!-- Left Sidebar: Avatar & Bukti Pembayaran -->
        <div class="detail-sidebar">
            <div class="user-avatar" style="width: 100px; height: 100px; font-size: 36px; margin: 0 auto 15px;">
                <?= strtoupper(substr($participant['name'], 0, 2)) ?>
            </div>
            <h3 style="font-weight: 600; margin-bottom: 5px;"><?= htmlspecialchars($participant['name']) ?></h3>
            <p style="color: var(--text-muted); font-size: 13px; margin-bottom: 25px;">NIM/ID: <?= htmlspecialchars($participant['id']) ?></p>

            <h4 style="font-weight: 600; font-size: 14px; text-align: left; margin-bottom: 10px; border-bottom: 1px solid var(--border); padding-bottom: 5px;">
                <i class="fa-solid fa-file-invoice-dollar"></i> Bukti Pembayaran
            </h4>

            <div class="detail-proof-box">
                <?php if ($isImg): ?>
                    <a href="uploads/<?= $proof ?>" target="_blank" title="Klik untuk memperbesar">
                        <img src="uploads/<?= $proof ?>" alt="Bukti Pembayaran" class="proof-img">
                    </a>
                <?php elseif ($isPdf): ?>
                    <div class="proof-pdf">
                        <i class="fa-solid fa-file-pdf"></i>
                    </div>
                    <a href="uploads/<?= $proof ?>" target="_blank" class="btn btn-outline" style="padding: 6px 12px; font-size: 12px;">
                        <i class="fa-solid fa-up-right-from-square"></i> Lihat PDF Bukti
                    </a>
                <?php else: ?>
                    <div style="color: var(--text-muted); text-align: center;">
                        <i class="fa-regular fa-image" style="font-size: 40px; margin-bottom: 10px; opacity: 0.4;"></i>
                        <p style="font-size: 12px;">Belum ada bukti pembayaran yang diunggah.</p>
                    </div>
                <?php endif; ?>
            </div>

            <div style="margin-top: 15px;">
                <a href="index.php?action=upload_payment&id=<?= $participant['id'] ?>" class="btn btn-primary btn-block" style="padding: 10px; font-size: 13px;">
                    <i class="fa-solid fa-upload"></i> Unggah / Ganti Bukti
                </a>
            </div>
        </div>

        <!-- Right Side: Informasi Detail -->
        <div class="detail-info-pane">
            <h4 style="font-weight: 600; font-size: 15px; margin-bottom: 15px; color: var(--primary); border-bottom: 1px solid var(--border); padding-bottom: 8px;">
                <i class="fa-solid fa-circle-info"></i> Biodata Lengkap
            </h4>
            
            <div class="detail-fields" style="margin-bottom: 30px;">
                <div class="detail-field-item">
                    <label>Nama Lengkap</label>
                    <p><?= htmlspecialchars($participant['name']) ?></p>
                </div>
                
                <div class="detail-field-item">
                    <label>NIM / ID Peserta</label>
                    <p><?= htmlspecialchars($participant['id']) ?></p>
                </div>

                <div class="detail-field-item">
                    <label>Alamat Email</label>
                    <p><?= htmlspecialchars($participant['email']) ?></p>
                </div>

                <div class="detail-field-item">
                    <label>Nomor HP / WhatsApp</label>
                    <p><?= htmlspecialchars($participant['phone']) ?></p>
                </div>

                <div class="detail-field-item">
                    <label>Jenis Kelamin</label>
                    <p><?= $participant['gender'] ?></p>
                </div>

                <div class="detail-field-item">
                    <label>Tanggal Pendaftaran</label>
                    <p><?= date('d-m-Y', strtotime($participant['registration_date'])) ?></p>
                </div>
            </div>

            <h4 style="font-weight: 600; font-size: 15px; margin-bottom: 15px; color: var(--primary); border-bottom: 1px solid var(--border); padding-bottom: 8px;">
                <i class="fa-solid fa-calendar-check"></i> Detail Event yang Diikuti
            </h4>

            <div class="detail-fields" style="margin-bottom: 30px;">
                <div class="detail-field-item" style="grid-column: span 2;">
                    <label>Nama Event</label>
                    <p style="font-weight: 600; color: var(--secondary);"><?= htmlspecialchars($participant['event_name']) ?></p>
                </div>

                <div class="detail-field-item">
                    <label>Tanggal Pelaksanaan</label>
                    <p><?= date('d-m-Y', strtotime($participant['event_date'])) ?></p>
                </div>

                <div class="detail-field-item">
                    <label>Jam Mulai</label>
                    <p><?= date('H:i', strtotime($participant['event_time'])) ?></p>
                </div>

                <div class="detail-field-item" style="grid-column: span 2;">
                    <label>Lokasi Kegiatan</label>
                    <p><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($participant['event_location']) ?></p>
                </div>
            </div>

            <h4 style="font-weight: 600; font-size: 15px; margin-bottom: 15px; color: var(--primary); border-bottom: 1px solid var(--border); padding-bottom: 8px;">
                <i class="fa-solid fa-clipboard-user"></i> Status Keanggotaan
            </h4>

            <div class="detail-fields">
                <div class="detail-field-item">
                    <label>Status Pembayaran</label>
                    <p>
                        <?php if ($participant['payment_status'] === 'Paid'): ?>
                            <span class="badge badge-success" style="font-size: 14px; padding: 6px 16px;">Paid (Lunas)</span>
                        <?php elseif ($participant['payment_status'] === 'Pending'): ?>
                            <span class="badge badge-warning" style="font-size: 14px; padding: 6px 16px;">Pending (Verifikasi)</span>
                        <?php else: ?>
                            <span class="badge badge-danger" style="font-size: 14px; padding: 6px 16px;">Rejected (Ditolak)</span>
                        <?php endif; ?>
                    </p>
                </div>

                <div class="detail-field-item">
                    <label>Kehadiran Event</label>
                    <p>
                        <?php if ($participant['attendance_status'] === 'Present'): ?>
                            <span class="badge badge-success" style="font-size: 14px; padding: 6px 16px;">
                                <i class="fa-solid fa-clipboard-user"></i> Hadir
                            </span>
                        <?php else: ?>
                            <span class="badge badge-danger" style="font-size: 14px; padding: 6px 16px;">
                                <i class="fa-solid fa-user-slash"></i> Absen
                            </span>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
