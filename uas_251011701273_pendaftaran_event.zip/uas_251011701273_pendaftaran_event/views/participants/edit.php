<?php
// (("Include header layout"))
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Edit Data Peserta</h1>
        <p>Perbarui informasi pendaftaran dan verifikasi status peserta</p>
    </div>
    <div>
        <a href="index.php?action=participants" class="btn btn-outline">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
</div>

<div class="card-container">
    <div class="card-title-bar">
        <h3><i class="fa-solid fa-user-pen"></i> Edit Peserta NIM/ID: <?= htmlspecialchars($participant['id']) ?></h3>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form action="index.php?action=participant_edit&id=<?= $participant['id'] ?>" method="POST" enctype="multipart/form-data" class="needs-validation">
        <div class="form-grid">
            <!-- ID Peserta (Disabled / Readonly) -->
            <div class="form-group">
                <label for="id">NIM / ID Peserta (Kunci)</label>
                <input type="text" id="id" class="form-input" value="<?= htmlspecialchars($participant['id']) ?>" disabled>
            </div>
            
            <!-- Nama Peserta -->
            <div class="form-group">
                <label for="name">Nama Lengkap</label>
                <input type="text" id="name" name="name" class="form-input" value="<?= htmlspecialchars($participant['name']) ?>" required>
            </div>
        </div>

        <div class="form-grid">
            <!-- Email -->
            <div class="form-group">
                <label for="email">Alamat Email</label>
                <input type="email" id="email" name="email" class="form-input" value="<?= htmlspecialchars($participant['email']) ?>" required>
            </div>
            
            <!-- Nomor HP -->
            <div class="form-group">
                <label for="phone">Nomor HP</label>
                <input type="text" id="phone" name="phone" class="form-input validate-phone number-only" value="<?= htmlspecialchars($participant['phone']) ?>" required>
            </div>
        </div>

        <div class="form-grid">
            <!-- Jenis Kelamin -->
            <div class="form-group">
                <label for="gender">Jenis Kelamin</label>
                <select id="gender" name="gender" class="form-select" required>
                    <option value="Laki-laki" <?= $participant['gender'] === 'Laki-laki' ? 'selected' : '' ?>>Laki-laki</option>
                    <option value="Perempuan" <?= $participant['gender'] === 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
                </select>
            </div>
            
            <!-- Tanggal Daftar -->
            <div class="form-group">
                <label for="registration_date">Tanggal Pendaftaran</label>
                <input type="date" id="registration_date" name="registration_date" class="form-input" value="<?= htmlspecialchars($participant['registration_date']) ?>" required>
            </div>
        </div>

        <div class="form-grid">
            <!-- Event Dropdown -->
            <div class="form-group">
                <label for="event_id">Pilih Event</label>
                <select id="event_id" name="event_id" class="form-select" required>
                    <?php foreach ($events as $evt): ?>
                        <option value="<?= $evt['id'] ?>" <?= $participant['event_id'] == $evt['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($evt['name']) ?> (Kuota: <?= $evt['quota'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Bukti Pembayaran -->
            <div class="form-group">
                <label for="payment_proof">Ganti Bukti Pembayaran (Biarkan kosong jika tidak diganti)</label>
                <input type="file" id="payment_proof" name="payment_proof" class="form-input">
                <small style="color: var(--text-muted); font-size: 11px;">Format: JPG, PNG, PDF. Maksimal: 2 MB.</small>
                
                <?php if (!empty($participant['payment_proof'])): ?>
                    <div style="margin-top: 8px; font-size: 12px; color: var(--primary);">
                        <i class="fa-solid fa-paperclip"></i> File saat ini: 
                        <a href="uploads/<?= $participant['payment_proof'] ?>" target="_blank" style="text-decoration: underline; font-weight: 500;">
                            <?= htmlspecialchars($participant['payment_proof']) ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-grid">
            <!-- Status Pembayaran -->
            <div class="form-group">
                <label for="payment_status">Status Pembayaran</label>
                <select id="payment_status" name="payment_status" class="form-select">
                    <option value="Pending" <?= $participant['payment_status'] === 'Pending' ? 'selected' : '' ?>>Pending (Menunggu Verifikasi)</option>
                    <option value="Paid" <?= $participant['payment_status'] === 'Paid' ? 'selected' : '' ?>>Paid (Lunas)</option>
                    <option value="Rejected" <?= $participant['payment_status'] === 'Rejected' ? 'selected' : '' ?>>Rejected (Ditolak)</option>
                </select>
            </div>
            
            <!-- Status Kehadiran -->
            <div class="form-group">
                <label for="attendance_status">Status Kehadiran</label>
                <select id="attendance_status" name="attendance_status" class="form-select">
                    <option value="Absent" <?= $participant['attendance_status'] === 'Absent' ? 'selected' : '' ?>>Absent (Belum Hadir)</option>
                    <option value="Present" <?= $participant['attendance_status'] === 'Present' ? 'selected' : '' ?>>Present (Hadir)</option>
                </select>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
            </button>
            <a href="index.php?action=participants" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
