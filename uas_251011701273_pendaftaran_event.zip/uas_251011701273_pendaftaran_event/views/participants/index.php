<?php
// (("Include header layout"))
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Daftar Peserta Event</h1>
        <p>Kelola data pendaftaran peserta, pembayaran tiket, dan status kehadiran</p>
    </div>
    <div>
        <a href="index.php?action=participant_add" class="btn btn-primary">
            <i class="fa-solid fa-user-plus"></i> Tambah Peserta Baru
        </a>
    </div>
</div>

<!-- BAR FILTER & PENCARIAN -->
<div class="filter-search-bar">
    <form action="index.php" method="GET" class="filter-search-form">
        <input type="hidden" name="action" value="participants">
        
        <!-- Search Input -->
        <div class="form-group search-input-group">
            <input type="text" name="search" class="form-input" placeholder="Cari nama, email, NIM, nomor HP..." value="<?= htmlspecialchars($search) ?>">
        </div>

        <!-- Filter Event -->
        <div class="form-group">
            <select name="event_id" class="form-select">
                <option value="">Semua Event</option>
                <?php foreach ($events as $evt): ?>
                    <option value="<?= $evt['id'] ?>" <?= $event_id == $evt['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($evt['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Filter Status Pembayaran -->
        <div class="form-group">
            <select name="payment_status" class="form-select">
                <option value="">Semua Pembayaran</option>
                <option value="Pending" <?= $payment_status === 'Pending' ? 'selected' : '' ?>>Pending</option>
                <option value="Paid" <?= $payment_status === 'Paid' ? 'selected' : '' ?>>Lunas</option>
                <option value="Rejected" <?= $payment_status === 'Rejected' ? 'selected' : '' ?>>Ditolak</option>
            </select>
        </div>

        <!-- Sort By -->
        <div class="form-group">
            <select name="sort_by" class="form-select">
                <option value="registration_date" <?= $sort_by === 'registration_date' ? 'selected' : '' ?>>Urutkan: Tgl Daftar</option>
                <option value="name" <?= $sort_by === 'name' ? 'selected' : '' ?>>Urutkan: Nama Peserta</option>
                <option value="id" <?= $sort_by === 'id' ? 'selected' : '' ?>>Urutkan: NIM/ID</option>
                <option value="event_name" <?= $sort_by === 'event_name' ? 'selected' : '' ?>>Urutkan: Event</option>
            </select>
        </div>

        <!-- Sort Order -->
        <div class="form-group" style="min-width: 100px; flex-grow: 0;">
            <select name="sort_order" class="form-select">
                <option value="DESC" <?= $sort_order === 'DESC' ? 'selected' : '' ?>>Descending</option>
                <option value="ASC" <?= $sort_order === 'ASC' ? 'selected' : '' ?>>Ascending</option>
            </select>
        </div>

        <!-- Buttons -->
        <div>
            <button type="submit" class="btn btn-secondary">
                <i class="fa-solid fa-filter"></i> Filter
            </button>
            <a href="index.php?action=participants" class="btn btn-outline">
                <i class="fa-solid fa-rotate-left"></i> Reset
            </a>
        </div>
    </form>
</div>

<!-- TABLE DATA PESERTA -->
<div class="card-container">
    <div class="table-responsive">
        <table class="table-modern">
            <thead>
                <tr>
                    <th>NIM/ID</th>
                    <th>Nama Peserta</th>
                    <th>Email & HP</th>
                    <th>Nama Event</th>
                    <th>Tgl Daftar</th>
                    <th>Pembayaran</th>
                    <th>Kehadiran</th>
                    <th style="text-align: center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($participants)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px 0;">
                            <i class="fa-regular fa-folder-open" style="font-size: 35px; margin-bottom: 10px; opacity: 0.5;"></i>
                            <p>Data peserta tidak ditemukan atau masih kosong.</p>
                        </td>
                    </tr>
                <?php else: 
                    foreach ($participants as $part):
                ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($part['id']) ?></strong></td>
                        <td>
                            <div style="font-weight: 600;"><?= htmlspecialchars($part['name']) ?></div>
                            <span style="font-size: 11px; color: var(--text-muted);"><?= $part['gender'] ?></span>
                        </td>
                        <td>
                            <div><?= htmlspecialchars($part['email']) ?></div>
                            <span style="font-size: 11px; color: var(--text-muted);"><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($part['phone']) ?></span>
                        </td>
                        <td>
                            <div style="font-weight: 500;"><?= htmlspecialchars($part['event_name']) ?></div>
                            <span style="font-size: 11px; color: var(--text-muted);"><i class="fa-regular fa-calendar"></i> <?= date('d-m-Y', strtotime($part['event_date'])) ?></span>
                        </td>
                        <td><?= date('d-m-Y', strtotime($part['registration_date'])) ?></td>
                        <td>
                            <?php if ($part['payment_status'] === 'Paid'): ?>
                                <span class="badge badge-success">Lunas</span>
                            <?php elseif ($part['payment_status'] === 'Pending'): ?>
                                <span class="badge badge-warning">Pending</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Ditolak</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($part['attendance_status'] === 'Present'): ?>
                                <span class="badge badge-success"><i class="fa-solid fa-clipboard-user"></i> Hadir</span>
                            <?php else: ?>
                                <span class="badge badge-danger"><i class="fa-solid fa-user-slash"></i> Absen</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-buttons" style="justify-content: center;">
                                <a href="index.php?action=participant_detail&id=<?= $part['id'] ?>" class="btn-icon btn-icon-info" title="Detail Peserta">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                                <a href="index.php?action=participant_edit&id=<?= $part['id'] ?>" class="btn-icon btn-icon-warning" title="Edit Peserta">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                                <a href="index.php?action=participant_delete&id=<?= $part['id'] ?>" class="btn-icon btn-icon-danger btn-delete-confirm" title="Hapus Peserta">
                                    <i class="fa-solid fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

    <!-- PAGINASI -->
    <?php if ($totalPages > 1): ?>
        <div class="pagination-container">
            <div class="pagination-info">
                Menampilkan halaman <strong><?= $page ?></strong> dari <strong><?= $totalPages ?></strong> (Total data: <strong><?= $totalItems ?></strong>)
            </div>
            <div class="pagination-links">
                <!-- Page Sebelumnya -->
                <a href="index.php?action=participants&page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&event_id=<?= $event_id ?>&payment_status=<?= $payment_status ?>&sort_by=<?= $sort_by ?>&sort_order=<?= $sort_order ?>" 
                   class="pagination-btn <?= $page <= 1 ? 'disabled' : '' ?>">
                    <i class="fa-solid fa-chevron-left"></i>
                </a>

                <!-- Angka Halaman -->
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="index.php?action=participants&page=<?= $i ?>&search=<?= urlencode($search) ?>&event_id=<?= $event_id ?>&payment_status=<?= $payment_status ?>&sort_by=<?= $sort_by ?>&sort_order=<?= $sort_order ?>" 
                       class="pagination-btn <?= $page === $i ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <!-- Page Berikutnya -->
                <a href="index.php?action=participants&page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&event_id=<?= $event_id ?>&payment_status=<?= $payment_status ?>&sort_by=<?= $sort_by ?>&sort_order=<?= $sort_order ?>" 
                   class="pagination-btn <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <i class="fa-solid fa-chevron-right"></i>
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
