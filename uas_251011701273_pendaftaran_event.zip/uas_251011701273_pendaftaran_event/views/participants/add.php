<?php
// (("Include header layout"))
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Tambah Peserta Baru</h1>
        <p>Daftarkan peserta secara manual ke dalam event pilihan</p>
    </div>
    <div>
        <a href="index.php?action=participants" class="btn btn-outline">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
</div>

<div class="card-container">
    <div class="card-title-bar">
        <h3><i class="fa-solid fa-user-plus"></i> Formulir Pendaftaran Peserta</h3>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form action="index.php?action=participant_add" method="POST" enctype="multipart/form-data" class="needs-validation">
        <div class="form-grid">
            <!-- ID Peserta (NIM) -->
            <div class="form-group">
                <label for="id">NIM / ID Peserta</label>
                <input type="text" id="id" name="id" class="form-input number-only" placeholder="Contoh: 251011701273" required>
                <small style="color: var(--text-muted); font-size: 11px;">Gunakan angka saja. ID tidak dapat diubah setelah disimpan.</small>
            </div>
            
            <!-- Nama Peserta -->
            <div class="form-group">
                <label for="name">Nama Lengkap</label>
                <input type="text" id="name" name="name" class="form-input" placeholder="Masukkan nama lengkap peserta" required>
            </div>
        </div>

        <div class="form-grid">
            <!-- Email -->
            <div class="form-group">
                <label for="email">Alamat Email</label>
                <input type="email" id="email" name="email" class="form-input" placeholder="Contoh: peserta@gmail.com" required>
            </div>
            
            <!-- Nomor HP -->
            <div class="form-group">
                <label for="phone">Nomor HP / WhatsApp</label>
                <input type="text" id="phone" name="phone" class="form-input validate-phone number-only" placeholder="Contoh: 081234567890" required>
            </div>
        </div>

        <div class="form-grid">
            <!-- Jenis Kelamin -->
            <div class="form-group">
                <label for="gender">Jenis Kelamin</label>
                <select id="gender" name="gender" class="form-select" required>
                    <option value="">Pilih Jenis Kelamin</option>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>
            
            <!-- Tanggal Daftar -->
            <div class="form-group">
                <label for="registration_date">Tanggal Pendaftaran</label>
                <input type="date" id="registration_date" name="registration_date" class="form-input" value="<?= date('Y-m-d') ?>" required>
            </div>
        </div>

        <div class="form-grid">
            <!-- Event Dropdown -->
            <div class="form-group">
                <label for="event_id">Pilih Event</label>
                <select id="event_id" name="event_id" class="form-select" required>
                    <option value="">Pilih Kegiatan Event</option>
                    <?php foreach ($events as $evt): ?>
                        <option value="<?= $evt['id'] ?>" <?= $evt['status'] !== 'Active' ? 'disabled' : '' ?>>
                            <?= htmlspecialchars($evt['name']) ?> 
                            (Kuota: <?= $evt['quota'] ?>) 
                            <?= $evt['status'] !== 'Active' ? '[TIDAK AKTIF]' : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Bukti Pembayaran (File Upload) -->
            <div class="form-group">
                <label for="payment_proof">Bukti Pembayaran (Optional)</label>
                <input type="file" id="payment_proof" name="payment_proof" class="form-input">
                <small style="color: var(--text-muted); font-size: 11px;">Format: JPG, PNG, PDF. Ukuran Maksimal: 2 MB.</small>
            </div>
        </div>

        <div class="form-grid">
            <!-- Status Pembayaran -->
            <div class="form-group">
                <label for="payment_status">Status Pembayaran</label>
                <select id="payment_status" name="payment_status" class="form-select">
                    <option value="Pending">Pending (Menunggu Verifikasi)</option>
                    <option value="Paid">Paid (Lunas)</option>
                    <option value="Rejected">Rejected (Ditolak)</option>
                </select>
            </div>
            
            <!-- Status Kehadiran -->
            <div class="form-group">
                <label for="attendance_status">Status Kehadiran</label>
                <select id="attendance_status" name="attendance_status" class="form-select">
                    <option value="Absent">Absent (Belum Hadir)</option>
                    <option value="Present">Present (Hadir di Lokasi)</option>
                </select>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-floppy-disk"></i> Simpan Pendaftaran
            </button>
            <a href="index.php?action=participants" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
