<?php
// (("Include header layout"))
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Upload Bukti Pembayaran</h1>
        <p>Unggah atau ganti berkas tanda bukti transfer pembayaran peserta</p>
    </div>
    <div>
        <a href="index.php?action=participant_detail&id=<?= $participant['id'] ?>" class="btn btn-outline">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Detail
        </a>
    </div>
</div>

<div class="card-container" style="max-width: 600px; margin: 0 auto;">
    <div class="card-title-bar">
        <h3><i class="fa-solid fa-cloud-arrow-up"></i> Upload Berkas Peserta</h3>
    </div>

    <div style="background-color: var(--bg-main); padding: 15px; border-radius: var(--radius-sm); margin-bottom: 20px;">
        <table style="width: 100%; font-size: 13px;">
            <tr>
                <td style="width: 120px; font-weight: 600; color: var(--text-muted);">NIM / ID</td>
                <td>: <?= htmlspecialchars($participant['id']) ?></td>
            </tr>
            <tr>
                <td style="font-weight: 600; color: var(--text-muted);">Nama Lengkap</td>
                <td>: <strong><?= htmlspecialchars($participant['name']) ?></strong></td>
            </tr>
            <tr>
                <td style="font-weight: 600; color: var(--text-muted);">Event</td>
                <td>: <?= htmlspecialchars($participant['event_name']) ?></td>
            </tr>
        </table>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form action="index.php?action=upload_payment&id=<?= $participant['id'] ?>" method="POST" enctype="multipart/form-data" class="needs-validation">
        <div class="form-group">
            <label for="payment_proof">Pilih File Bukti Pembayaran</label>
            <input type="file" id="payment_proof" name="payment_proof" class="form-input" required>
            <small style="color: var(--text-muted); display: block; margin-top: 5px;">Format yang didukung: JPG, PNG, PDF. Ukuran berkas maksimal 2 MB.</small>
        </div>

        <div class="form-group" style="margin-top: 20px;">
            <label for="payment_status">Status Pembayaran Baru</label>
            <select id="payment_status" name="payment_status" class="form-select">
                <option value="Paid" <?= $participant['payment_status'] === 'Paid' ? 'selected' : '' ?>>Paid (Lunas / Valid)</option>
                <option value="Pending" <?= $participant['payment_status'] === 'Pending' ? 'selected' : '' ?>>Pending (Menunggu Verifikasi)</option>
                <option value="Rejected" <?= $participant['payment_status'] === 'Rejected' ? 'selected' : '' ?>>Rejected (Ditolak)</option>
            </select>
        </div>

        <div class="form-actions" style="margin-top: 30px;">
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-circle-check"></i> Proses Upload & Simpan
            </button>
            <a href="index.php?action=participant_detail&id=<?= $participant['id'] ?>" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
