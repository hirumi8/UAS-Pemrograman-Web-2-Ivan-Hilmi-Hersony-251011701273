            </main>
            <!-- Page Content Ends -->

            <!-- FOOTER -->
            <footer class="footer-text">
                <p>&copy; <?= date('Y') ?> - Sistem Informasi Pendaftaran Event. UAS Pemrograman Web II.</p>
                <p style="margin-top: 5px; font-weight: 500;">
                    Mahasiswa: <strong>Ivan Hilmi Hersony</strong> (NIM: <strong>251011701273</strong>) | Dosen Pengampu - Pemrograman Web II
                </p>
            </footer>
        </div>
    </div>

    <!-- Custom JavaScript -->
    <script src="assets/js/main.js"></script>
</body>
</html>
