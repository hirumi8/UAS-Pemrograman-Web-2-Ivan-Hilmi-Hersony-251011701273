<?php
 // (("Layout Header Menampilkan bagian atas halaman admin, Sidebar navigasi dan Top Navbar."))
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_action = $_GET['action'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HilmiEvent - UAS Ivan Hilmi Hersony</title>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="app-wrapper">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <a href="index.php?action=dashboard" class="sidebar-logo">
                    <i class="fa-solid fa-calendar-days"></i>
                    <span>Hilmi<span>Event</span></span>
                </a>
                <button class="sidebar-toggle-btn">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>
            
            <nav class="sidebar-menu">
                <div class="menu-label">Main Menu</div>
                <ul>
                    <li class="menu-item <?= $current_action === 'dashboard' ? 'active' : '' ?>">
                        <a href="index.php?action=dashboard" class="menu-link">
                            <i class="fa-solid fa-chart-line"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="menu-item <?= strpos($current_action, 'event') !== false ? 'active' : '' ?>">
                        <a href="index.php?action=events" class="menu-link">
                            <i class="fa-solid fa-calendar-check"></i>
                            <span>Data Event</span>
                        </a>
                    </li>
                    <li class="menu-item <?= (strpos($current_action, 'participant') !== false || $current_action === 'upload_payment') ? 'active' : '' ?>">
                        <a href="index.php?action=participants" class="menu-link">
                            <i class="fa-solid fa-users"></i>
                            <span>Data Peserta</span>
                        </a>
                    </li>
                    <li class="menu-item <?= $current_action === 'reports' ? 'active' : '' ?>">
                        <a href="index.php?action=reports" class="menu-link">
                            <i class="fa-solid fa-file-invoice"></i>
                            <span>Laporan (PDF/Excel)</span>
                        </a>
                    </li>
                </ul>

                <div class="menu-label" style="margin-top: 25px;">Akun</div>
                <ul>
                    <li class="menu-item <?= $current_action === 'profile' ? 'active' : '' ?>">
                        <a href="index.php?action=profile" class="menu-link">
                            <i class="fa-solid fa-user-gear"></i>
                            <span>Pengaturan Profil</span>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="index.php?action=logout" class="menu-link" style="color: var(--danger);">
                            <i class="fa-solid fa-right-from-bracket"></i>
                            <span>Log Out</span>
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Sidebar Student Profile Card -->
            <div class="sidebar-footer">
                <div class="user-profile-summary">
                    <div class="user-avatar">
                        IH
                    </div>
                    <div class="user-info-text">
                        <h4><?= htmlspecialchars($user['name'] ?? 'Ivan Hilmi H') ?></h4>
                        <p>NIM: 251011701273</p>
                    </div>
                </div>
            </div>
        </aside>

        <!-- MAIN AREA -->
        <div class="main-content">
            <!-- TOP NAVBAR -->
            <header class="top-navbar">
                <div class="navbar-left">
                    <span class="system-time" id="live-time">
                        <i class="fa-regular fa-clock"></i> Memuat waktu...
                    </span>
                </div>
                <div class="navbar-right">
                    <span style="font-weight: 500; font-size: 13px;">
                        Status: <span class="badge badge-success">UAS P. Web 2</span>
                    </span>
                    <a href="index.php?action=logout" class="header-logout-btn">
                        <i class="fa-solid fa-power-off"></i> Keluar
                    </a>
                </div>
            </header>
            
            <!-- Page Content Starts -->
            <main class="content-body">
                <!-- Alert Messages from Session -->
                <?php if (isset($_SESSION['success_msg'])): ?>
                    <div class="alert alert-success">
                        <i class="fa-solid fa-circle-check"></i>
                        <?= $_SESSION['success_msg']; unset($_SESSION['success_msg']); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error_msg'])): ?>
                    <div class="alert alert-danger">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <?= $_SESSION['error_msg']; unset($_SESSION['error_msg']); ?>
                    </div>
                <?php endif; ?>
