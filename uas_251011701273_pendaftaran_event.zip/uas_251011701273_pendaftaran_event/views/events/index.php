<?php
// (("Include header layout"))
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Daftar Event</h1>
        <p>Kelola seluruh data event/kegiatan seminar, workshop, dan bootcamp</p>
    </div>
    <div>
        <a href="index.php?action=event_add" class="btn btn-primary">
            <i class="fa-solid fa-plus"></i> Tambah Event Baru
        </a>
    </div>
</div>

<!-- BAR PENCARIAN & FILTER -->
<div class="filter-search-bar">
    <form action="index.php" method="GET" class="filter-search-form">
        <input type="hidden" name="action" value="events">
        
        <!-- Search Input -->
        <div class="form-group search-input-group">
            <input type="text" name="search" class="form-input" placeholder="Cari nama event atau lokasi..." value="<?= htmlspecialchars($search) ?>">
        </div>

        <!-- Filter Status -->
        <div class="form-group">
            <select name="status" class="form-select">
                <option value="">Semua Status</option>
                <option value="Active" <?= $status === 'Active' ? 'selected' : '' ?>>Aktif</option>
                <option value="Completed" <?= $status === 'Completed' ? 'selected' : '' ?>>Selesai</option>
                <option value="Cancelled" <?= $status === 'Cancelled' ? 'selected' : '' ?>>Dibatalkan</option>
            </select>
        </div>

        <!-- Sort By -->
        <div class="form-group">
            <select name="sort_by" class="form-select">
                <option value="date" <?= $sort_by === 'date' ? 'selected' : '' ?>>Urutkan: Tanggal</option>
                <option value="name" <?= $sort_by === 'name' ? 'selected' : '' ?>>Urutkan: Nama Event</option>
                <option value="quota" <?= $sort_by === 'quota' ? 'selected' : '' ?>>Urutkan: Kuota</option>
                <option value="location" <?= $sort_by === 'location' ? 'selected' : '' ?>>Urutkan: Lokasi</option>
            </select>
        </div>

        <!-- Sort Order -->
        <div class="form-group" style="min-width: 100px; flex-grow: 0;">
            <select name="sort_order" class="form-select">
                <option value="ASC" <?= $sort_order === 'ASC' ? 'selected' : '' ?>>Ascending</option>
                <option value="DESC" <?= $sort_order === 'DESC' ? 'selected' : '' ?>>Descending</option>
            </select>
        </div>

        <!-- Buttons -->
        <div>
            <button type="submit" class="btn btn-secondary">
                <i class="fa-solid fa-filter"></i> Filter
            </button>
            <a href="index.php?action=events" class="btn btn-outline">
                <i class="fa-solid fa-rotate-left"></i> Reset
            </a>
        </div>
    </form>
</div>

<!-- TABLE DATA EVENT -->
<div class="card-container">
    <div class="table-responsive">
        <table class="table-modern">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Event</th>
                    <th>Lokasi</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Kuota</th>
                    <th>Harga Tiket</th>
                    <th>Status</th>
                    <th style="text-align: center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($events)): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; color: var(--text-muted); padding: 40px 0;">
                            <i class="fa-regular fa-folder-open" style="font-size: 35px; margin-bottom: 10px; opacity: 0.5;"></i>
                            <p>Data Event tidak ditemukan atau masih kosong.</p>
                        </td>
                    </tr>
                <?php else: 
                    $no = $offset + 1;
                    foreach ($events as $evt):
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= htmlspecialchars($evt['name']) ?></strong></td>
                        <td><?= htmlspecialchars($evt['location']) ?></td>
                        <td><?= date('d-m-Y', strtotime($evt['date'])) ?></td>
                        <td><?= date('H:i', strtotime($evt['time'])) ?></td>
                        <td><?= $evt['quota'] ?> Peserta</td>
                        <td><strong><?= $evt['price'] == 0 ? 'Gratis' : 'Rp ' . number_format($evt['price'], 0, ',', '.') ?></strong></td>
                        <td>
                            <?php if ($evt['status'] === 'Active'): ?>
                                <span class="badge badge-success">Aktif</span>
                            <?php elseif ($evt['status'] === 'Completed'): ?>
                                <span class="badge badge-info">Selesai</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Dibatalkan</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-buttons" style="justify-content: center;">
                                <a href="index.php?action=event_edit&id=<?= $evt['id'] ?>" class="btn-icon btn-icon-warning" title="Edit Event">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                                <a href="index.php?action=event_delete&id=<?= $evt['id'] ?>" class="btn-icon btn-icon-danger btn-delete-confirm" title="Hapus Event">
                                    <i class="fa-solid fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

    <!-- PAGINASI -->
    <?php if ($totalPages > 1): ?>
        <div class="pagination-container">
            <div class="pagination-info">
                Menampilkan halaman <strong><?= $page ?></strong> dari <strong><?= $totalPages ?></strong> (Total data: <strong><?= $totalItems ?></strong>)
            </div>
            <div class="pagination-links">
                <!-- Page Sebelumnya -->
                <a href="index.php?action=events&page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&status=<?= $status ?>&sort_by=<?= $sort_by ?>&sort_order=<?= $sort_order ?>" 
                   class="pagination-btn <?= $page <= 1 ? 'disabled' : '' ?>">
                    <i class="fa-solid fa-chevron-left"></i>
                </a>

                <!-- Angka Halaman -->
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="index.php?action=events&page=<?= $i ?>&search=<?= urlencode($search) ?>&status=<?= $status ?>&sort_by=<?= $sort_by ?>&sort_order=<?= $sort_order ?>" 
                       class="pagination-btn <?= $page === $i ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <!-- Page Berikutnya -->
                <a href="index.php?action=events&page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&status=<?= $status ?>&sort_by=<?= $sort_by ?>&sort_order=<?= $sort_order ?>" 
                   class="pagination-btn <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <i class="fa-solid fa-chevron-right"></i>
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
