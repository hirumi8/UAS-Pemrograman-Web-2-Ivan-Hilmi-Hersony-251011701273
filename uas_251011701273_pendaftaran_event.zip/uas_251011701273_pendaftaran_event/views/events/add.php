<?php
// (("Include header layout"))
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Tambah Event Baru</h1>
        <p>Isi formulir berikut untuk merilis event/kegiatan baru</p>
    </div>
    <div>
        <a href="index.php?action=events" class="btn btn-outline">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
</div>

<div class="card-container">
    <div class="card-title-bar">
        <h3><i class="fa-solid fa-calendar-plus"></i> Formulir Pembuatan Event</h3>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form action="index.php?action=event_add" method="POST" class="needs-validation">
        <div class="form-group">
            <label for="name">Nama Event</label>
            <input type="text" id="name" name="name" class="form-input" placeholder="Masukkan nama event/seminar/workshop" required>
        </div>

        <div class="form-group">
            <label for="location">Lokasi Kegiatan</label>
            <input type="text" id="location" name="location" class="form-input" placeholder="Contoh: Gedung A / Virtual Zoom" required>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label for="date">Tanggal Pelaksanaan</label>
                <input type="date" id="date" name="date" class="form-input" required>
            </div>
            
            <div class="form-group">
                <label for="time">Jam Mulai</label>
                <input type="time" id="time" name="time" class="form-input" required>
            </div>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label for="quota">Kuota Maksimal Peserta</label>
                <input type="number" id="quota" name="quota" class="form-input number-only" placeholder="Contoh: 100" min="1" required>
            </div>

            <div class="form-group">
                <label for="price">Harga Tiket (Rp)</label>
                <input type="number" id="price" name="price" class="form-input number-only" placeholder="Masukkan harga (0 jika Gratis)" min="0" required>
            </div>
            
            <div class="form-group">
                <label for="status">Status Awal</label>
                <select id="status" name="status" class="form-select">
                    <option value="Active">Aktif</option>
                    <option value="Completed">Selesai</option>
                    <option value="Cancelled">Dibatalkan</option>
                </select>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-floppy-disk"></i> Simpan Event
            </button>
            <a href="index.php?action=events" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
