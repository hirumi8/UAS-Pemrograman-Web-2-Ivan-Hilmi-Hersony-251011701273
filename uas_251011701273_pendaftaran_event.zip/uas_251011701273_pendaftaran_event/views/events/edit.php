<?php
// (("Include header layout"))
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Edit Data Event</h1>
        <p>Perbarui informasi detail kegiatan terpilih</p>
    </div>
    <div>
        <a href="index.php?action=events" class="btn btn-outline">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
</div>

<div class="card-container">
    <div class="card-title-bar">
        <h3><i class="fa-solid fa-pen-to-square"></i> Formulir Perubahan Event: <?= htmlspecialchars($event['name']) ?></h3>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form action="index.php?action=event_edit&id=<?= $event['id'] ?>" method="POST" class="needs-validation">
        <div class="form-group">
            <label for="name">Nama Event</label>
            <input type="text" id="name" name="name" class="form-input" value="<?= htmlspecialchars($event['name']) ?>" required>
        </div>

        <div class="form-group">
            <label for="location">Lokasi Kegiatan</label>
            <input type="text" id="location" name="location" class="form-input" value="<?= htmlspecialchars($event['location']) ?>" required>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label for="date">Tanggal Pelaksanaan</label>
                <input type="date" id="date" name="date" class="form-input" value="<?= htmlspecialchars($event['date']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="time">Jam Mulai</label>
                <input type="time" id="time" name="time" class="form-input" value="<?= htmlspecialchars($event['time']) ?>" required>
            </div>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label for="quota">Kuota Maksimal Peserta</label>
                <input type="number" id="quota" name="quota" class="form-input number-only" value="<?= htmlspecialchars($event['quota']) ?>" min="1" required>
            </div>

            <div class="form-group">
                <label for="price">Harga Tiket (Rp)</label>
                <input type="number" id="price" name="price" class="form-input number-only" value="<?= htmlspecialchars($event['price']) ?>" min="0" required>
            </div>
            
            <div class="form-group">
                <label for="status">Status Event</label>
                <select id="status" name="status" class="form-select">
                    <option value="Active" <?= $event['status'] === 'Active' ? 'selected' : '' ?>>Aktif</option>
                    <option value="Completed" <?= $event['status'] === 'Completed' ? 'selected' : '' ?>>Selesai</option>
                    <option value="Cancelled" <?= $event['status'] === 'Cancelled' ? 'selected' : '' ?>>Dibatalkan</option>
                </select>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
            </button>
            <a href="index.php?action=events" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
