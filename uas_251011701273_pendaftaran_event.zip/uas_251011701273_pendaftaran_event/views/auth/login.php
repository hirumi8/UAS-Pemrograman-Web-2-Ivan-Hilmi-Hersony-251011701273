<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - HilmiEvent</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-split-container">
    
    <!-- LEFT SIDE: VISUAL & ACADEMIC INFO -->
    <div class="auth-split-left">
        <div class="auth-split-left-content">
            <div class="auth-split-logo">
                <i class="fa-solid fa-calendar-days"></i>
                <span>Hilmi<span>Event</span></span>
            </div>
            
            <div class="academic-badge-split">
                <i class="fa-solid fa-graduation-cap"></i> UAS Pemrograman Web II
            </div>
            
            <h1 class="split-hero-title">Sistem Informasi Pendaftaran Event</h1>
            <p class="split-hero-subtitle">Portal manajemen kegiatan seminar, workshop teknologi, dan bootcamp akademik secara terintegrasi dan sistematis.</p>
            
            <div class="split-features">
                <div class="split-feature-item">
                    <i class="fa-solid fa-circle-check"></i>
                    <div>
                        <strong>Pengelolaan Data Event Kompleks</strong>
                        <span>Atur kuota, jadwal, harga tiket, dan status pelaksanaan event secara dinamis.</span>
                    </div>
                </div>
                <div class="split-feature-item">
                    <i class="fa-solid fa-circle-check"></i>
                    <div>
                        <strong>Verifikasi Pembayaran Peserta</strong>
                        <span>Verifikasi unggahan berkas bukti transfer dengan sistem validasi file yang ketat.</span>
                    </div>
                </div>
                <div class="split-feature-item">
                    <i class="fa-solid fa-circle-check"></i>
                    <div>
                        <strong>Laporan Ekspor PDF & Excel</strong>
                        <span>Unduh ringkasan data pendaftaran berformat PDF cetak atau tabel Excel .xls instan.</span>
                    </div>
                </div>
            </div>
            
            <div class="split-left-footer">
                <p>Pengembang: <strong>Ivan Hilmi Hersony</strong> | NIM. <strong>251011701273</strong></p>
                <p style="margin-top: 5px; opacity: 0.8;">Dosen Pengampu: Samso Supriyatna, S.Kom., M.Kom</p>
            </div>
        </div>
    </div>
    
    <!-- RIGHT SIDE: LOGIN FORM -->
    <div class="auth-split-right">
        <div class="auth-split-right-form-wrapper">
            <div style="margin-bottom: 30px; text-align: center;">
                <h2 style="font-weight: 700; color: var(--text-main); font-size: 24px; margin-bottom: 8px;">Selamat Datang</h2>
                <p style="color: var(--text-muted); font-size: 13px;">Silakan masuk menggunakan akun admin Anda</p>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" style="font-size: 13px; padding: 10px 14px;">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success_msg'])): ?>
                <div class="alert alert-success" style="font-size: 13px; padding: 10px 14px;">
                    <i class="fa-solid fa-circle-check"></i>
                    <?= $_SESSION['success_msg']; unset($_SESSION['success_msg']); ?>
                </div>
            <?php endif; ?>

            <form action="index.php?action=login" method="POST" class="needs-validation">
                <div class="form-group" style="margin-bottom: 20px;">
                    <label for="username" style="font-size: 13px; font-weight: 600;">Username</label>
                    <input type="text" id="username" name="username" class="form-input" placeholder="Contoh: ivanhilmi" required>
                </div>

                <div class="form-group" style="margin-bottom: 25px;">
                    <label for="password" style="font-size: 13px; font-weight: 600;">Password</label>
                    <input type="password" id="password" name="password" class="form-input" placeholder="Masukkan password Anda" required>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="padding: 14px; font-size: 14px;">
                    <i class="fa-solid fa-right-to-bracket"></i> Masuk ke Dashboard
                </button>
            </form>
            
            <div class="auth-footer" style="margin-top: 30px; border-top: 1px solid var(--border); padding-top: 20px;">
                <p style="font-size: 13px;">Belum memiliki akun? <a href="index.php?action=register">Daftar Akun</a></p>
                
                <div style="margin-top: 20px; font-size: 11px; background-color: #fafbfe; padding: 12px; border-radius: 8px; border: 1px solid rgba(0, 45, 98, 0.05); text-align: left; line-height: 1.5;">
                    <span style="display: block; font-weight: 600; color: var(--primary); margin-bottom: 5px;"><i class="fa-solid fa-circle-info"></i> Info Akun Registrasi UAS:</span>
                    <strong>Username:</strong> ivanhilmi<br>
                    <strong>Password:</strong> password123
                </div>
            </div>
        </div>
    </div>
    
    <script src="assets/js/main.js"></script>
</body>
</html>
