<?php
// (("Include header layout"))
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Pengaturan Profil Pengguna</h1>
        <p>Kelola informasi detail profil admin organizer Anda</p>
    </div>
    <div>
        <a href="index.php?action=dashboard" class="btn btn-outline">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>
</div>

<div class="card-container">
    <div class="card-title-bar">
        <h3><i class="fa-solid fa-user-gear"></i> Informasi Akun & Keamanan</h3>
        <span class="badge badge-info">Admin</span>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success">
            <i class="fa-solid fa-circle-check"></i>
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <form action="index.php?action=profile" method="POST" class="needs-validation">
        <div class="form-grid">
            <div class="form-group">
                <label for="username">Username (Tidak dapat diubah)</label>
                <input type="text" id="username" class="form-input" value="<?= htmlspecialchars($user['username']) ?>" disabled>
            </div>
            
            <div class="form-group">
                <label for="name">Nama Lengkap</label>
                <input type="text" id="name" name="name" class="form-input" value="<?= htmlspecialchars($user['name']) ?>" required>
            </div>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-input" value="<?= htmlspecialchars($user['email']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="current_nim">NIM Mahasiswa</label>
                <input type="text" id="current_nim" class="form-input" value="251011701273" disabled>
            </div>
        </div>

        <div style="margin-top: 30px; margin-bottom: 15px; border-bottom: 1px solid var(--border); padding-bottom: 10px;">
            <h4 style="font-weight: 600; color: var(--primary);">Ubah Password (Kosongkan jika tidak ingin diubah)</h4>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label for="password">Password Baru</label>
                <input type="password" id="password" name="password" class="form-input" placeholder="Masukkan password baru">
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Konfirmasi Password Baru</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-input" placeholder="Ulangi password baru">
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan
            </button>
            <a href="index.php?action=dashboard" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
