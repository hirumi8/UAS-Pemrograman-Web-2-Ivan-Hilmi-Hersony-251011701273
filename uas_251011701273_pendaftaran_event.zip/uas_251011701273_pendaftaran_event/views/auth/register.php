<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun - HilmiEvent</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-split-container">
    
    <!-- LEFT SIDE: VISUAL & ACADEMIC INFO -->
    <div class="auth-split-left">
        <div class="auth-split-left-content">
            <div class="auth-split-logo">
                <i class="fa-solid fa-calendar-days"></i>
                <span>Hilmi<span>Event</span></span>
            </div>
            
            <div class="academic-badge-split">
                <i class="fa-solid fa-graduation-cap"></i> UAS Pemrograman Web II
            </div>
            
            <h1 class="split-hero-title">Registrasi Pengguna Baru</h1>
            <p class="split-hero-subtitle">Silakan daftarkan akun pengelola/admin baru untuk mengoperasikan portal administrasi HilmiEvent secara penuh.</p>
            
            <div class="split-features">
                <div class="split-feature-item">
                    <i class="fa-solid fa-circle-check"></i>
                    <div>
                        <strong>Akun Pribadi Mahasiswa</strong>
                        <span>Gunakan nama lengkap Anda dan Username registrasi sesuai ketentuan soal UAS.</span>
                    </div>
                </div>
                <div class="split-feature-item">
                    <i class="fa-solid fa-circle-check"></i>
                    <div>
                        <strong>Keamanan Akses Terjamin</strong>
                        <span>Sistem pendaftaran dilengkapi pengamanan hashing password standar industri.</span>
                    </div>
                </div>
                <div class="split-feature-item">
                    <i class="fa-solid fa-circle-check"></i>
                    <div>
                        <strong>Hak Akses Penuh</strong>
                        <span>Setiap akun baru yang terdaftar memiliki otorisasi penuh untuk mengelola data event dan mengekspor laporan.</span>
                    </div>
                </div>
            </div>
            
            <div class="split-left-footer">
                <p>Pengembang: <strong>Ivan Hilmi Hersony</strong> | NIM. <strong>251011701273</strong></p>
                <p style="margin-top: 5px; opacity: 0.8;">Dosen Pengampu: Samso Supriyatna, S.Kom., M.Kom</p>
            </div>
        </div>
    </div>
    
    <!-- RIGHT SIDE: REGISTER FORM -->
    <div class="auth-split-right">
        <div class="auth-split-right-form-wrapper" style="max-width: 480px; padding: 30px;">
            <div style="margin-bottom: 25px; text-align: center;">
                <h2 style="font-weight: 700; color: var(--text-main); font-size: 22px; margin-bottom: 6px;">Daftar Akun Baru</h2>
                <p style="color: var(--text-muted); font-size: 13px;">Lengkapi data di bawah ini untuk mendaftar</p>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" style="font-size: 12px; padding: 10px 14px; margin-bottom: 15px;">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success" style="font-size: 12px; padding: 10px 14px; margin-bottom: 15px;">
                    <i class="fa-solid fa-circle-check"></i>
                    <?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>

            <form action="index.php?action=register" method="POST" class="needs-validation">
                <div class="form-group" style="margin-bottom: 15px;">
                    <label for="name" style="font-size: 12px; font-weight: 600; margin-bottom: 6px;">Nama Lengkap</label>
                    <input type="text" id="name" name="name" class="form-input" style="padding: 10px 14px;" placeholder="Contoh: Ivan Hilmi Hersony" required>
                </div>

                <div class="form-group" style="margin-bottom: 15px;">
                    <label for="username" style="font-size: 12px; font-weight: 600; margin-bottom: 6px;">Username</label>
                    <input type="text" id="username" name="username" class="form-input" style="padding: 10px 14px;" placeholder="Contoh: ivanhilmi" required>
                </div>

                <div class="form-group" style="margin-bottom: 15px;">
                    <label for="email" style="font-size: 12px; font-weight: 600; margin-bottom: 6px;">Alamat Email</label>
                    <input type="email" id="email" name="email" class="form-input" style="padding: 10px 14px;" placeholder="Contoh: ivan@domain.com" required>
                </div>

                <div class="form-group" style="margin-bottom: 15px;">
                    <label for="password" style="font-size: 12px; font-weight: 600; margin-bottom: 6px;">Password</label>
                    <input type="password" id="password" name="password" class="form-input" style="padding: 10px 14px;" placeholder="Minimal 6 karakter" required>
                </div>

                <div class="form-group" style="margin-bottom: 20px;">
                    <label for="confirm_password" style="font-size: 12px; font-weight: 600; margin-bottom: 6px;">Konfirmasi Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-input" style="padding: 10px 14px;" placeholder="Ulangi password" required>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="padding: 12px; font-size: 13px;">
                    <i class="fa-solid fa-user-plus"></i> Daftarkan Akun
                </button>
            </form>
            
            <div class="auth-footer" style="margin-top: 20px; border-top: 1px solid var(--border); padding-top: 15px;">
                <p style="font-size: 13px;">Sudah memiliki akun? <a href="index.php?action=login">Masuk Disini</a></p>
            </div>
        </div>
    </div>
    
    <script src="assets/js/main.js"></script>
</body>
</html>
