<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Pendaftaran Event - Ivan Hilmi Hersony</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #fff;
            color: #333;
            margin: 30px;
            padding: 0;
            font-size: 12px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px double #333;
            padding-bottom: 15px;
        }

        .header h1 {
            font-size: 22px;
            margin: 0;
            text-transform: uppercase;
        }

        .header h2 {
            font-size: 14px;
            font-weight: 500;
            margin: 5px 0 0 0;
            color: #666;
        }

        .meta-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            font-size: 11px;
            color: #555;
        }

        .meta-info-left table td {
            padding: 3px 5px;
        }

        .meta-info-right {
            text-align: right;
        }

        table.data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table.data-table th {
            background-color: #f2f2f2;
            color: #000;
            font-weight: 600;
            border: 1px solid #999;
            padding: 10px 8px;
            text-align: left;
        }

        table.data-table td {
            border: 1px solid #999;
            padding: 8px;
            vertical-align: top;
        }

        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            border: 1px solid #ccc;
        }

        .footer-sig {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
        }

        .sig-box {
            text-align: center;
            width: 200px;
        }

        .sig-space {
            height: 70px;
        }

        /* Tampilan khusus untuk tombol Cetak ketika dibuka di browser */
        .no-print-bar {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 6px;
        }

        .btn {
            background-color: #6C63FF;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 13px;
        }

        .btn-outline {
            background-color: transparent;
            color: #333;
            border: 1px solid #ccc;
        }

        @media print {
            .no-print-bar {
                display: none !important;
            }
            body {
                margin: 0;
            }
        }
    </style>
</head>
<body>

    <!-- Bar Kontrol Browser (Hilang saat print) -->
    <div class="no-print-bar">
        <div>
            <strong>Preview Laporan Resmi</strong> - Silakan cetak dokumen ini atau simpan sebagai PDF.
        </div>
        <div style="display: flex; gap: 10px;">
            <button onclick="window.print();" class="btn">
                <i class="fa-solid fa-print"></i> Cetak / Simpan PDF
            </button>
            <button onclick="window.close();" class="btn btn-outline">
                Tutup Halaman
            </button>
        </div>
    </div>

    <!-- HEADER LAPORAN -->
    <div class="header">
        <h1>Laporan Resmi Pendaftaran Event</h1>
        <h2>Sistem Informasi Pendaftaran Event - EventGrids</h2>
        <p style="margin: 5px 0 0 0; font-size: 11px;">Materi Ujian Akhir Semester Pemrograman Web II</p>
    </div>

    <!-- METADATA FILTER & PENULIS -->
    <div class="meta-info">
        <div class="meta-info-left">
            <table>
                <tr>
                    <td><strong>Event Filter</strong></td>
                    <td>: <?= htmlspecialchars($eventNameFilter) ?></td>
                </tr>
                <tr>
                    <td><strong>Filter Tanggal</strong></td>
                    <td>: <?= !empty($date) ? date('d-m-Y', strtotime($date)) : 'Semua Tanggal' ?></td>
                </tr>
                <tr>
                    <td><strong>Status Pembayaran</strong></td>
                    <td>: <?= !empty($payment_status) ? $payment_status : 'Semua Status' ?></td>
                </tr>
            </table>
        </div>
        <div class="meta-info-right">
            <div><strong>Dicetak Oleh</strong>: Ivan Hilmi Hersony</div>
            <div><strong>NIM</strong>: 251011701273</div>
            <div><strong>Tanggal Cetak</strong>: <?= date('d-m-Y H:i:s') ?></div>
        </div>
    </div>

    <!-- DATA TABLE -->
    <table class="data-table">
        <thead>
            <tr>
                <th style="width: 5%">No</th>
                <th style="width: 15%">NIM / ID Peserta</th>
                <th style="width: 20%">Nama Peserta</th>
                <th style="width: 20%">Kontak (Email/HP)</th>
                <th style="width: 20%">Nama Event</th>
                <th style="width: 10%">Tgl Daftar</th>
                <th style="width: 10%">Status Bayar</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($reportData)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 20px;">Tidak ada data pendaftaran yang ditemukan.</td>
                </tr>
            <?php else: 
                $no = 1;
                foreach ($reportData as $row):
            ?>
                <tr>
                    <td style="text-align: center;"><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($row['id']) ?></strong></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td>
                        <div><?= htmlspecialchars($row['email']) ?></div>
                        <div style="font-size: 10px; color: #555;"><?= htmlspecialchars($row['phone']) ?></div>
                    </td>
                    <td><?= htmlspecialchars($row['event_name']) ?></td>
                    <td><?= date('d-m-Y', strtotime($row['registration_date'])) ?></td>
                    <td style="text-align: center;">
                        <span class="badge">
                            <?= $row['payment_status'] ?>
                        </span>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>

    <!-- TANDA TANGAN -->
    <div class="footer-sig">
        <div class="sig-box">
            <div>Mengetahui,</div>
            <div><strong>Dosen Pengampu</strong></div>
            <div class="sig-space"></div>
            <div style="border-top: 1px solid #000; display: inline-block; width: 100%; padding-top: 5px;">Tanda Tangan & Nama</div>
        </div>
        <div class="sig-box">
            <div>Tangerang Selatan, <?= date('d-m-Y') ?></div>
            <div><strong>Administrator</strong></div>
            <div class="sig-space"></div>
            <div style="border-top: 1px solid #000; display: inline-block; width: 100%; padding-top: 5px;">
                <strong>Ivan Hilmi Hersony</strong><br>
                NIM. 251011701273
            </div>
        </div>
    </div>

    <!-- AUTO-PRINT TRIGGER -->
    <script>
        window.onload = function() {
            // Berikan jeda kecil agar loading selesai sempurna, lalu buka dialog print
            setTimeout(function() {
                window.print();
            }, 500);
        }
    </script>
</body>
</html>
