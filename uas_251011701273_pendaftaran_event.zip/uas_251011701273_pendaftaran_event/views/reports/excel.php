<?php
/**
 * Layout Laporan Excel (.xls)
 * Menggunakan format HTML table yang dibaca oleh MS Excel.
 */
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th {
            background-color: #4F81BD;
            color: white;
            font-weight: bold;
            border: 1px solid #000;
            padding: 8px;
        }
        td {
            border: 1px solid #000;
            padding: 8px;
        }
        .header-title {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>

    <table>
        <tr>
            <td colspan="8" class="header-title" style="text-align: center;"><strong>LAPORAN RESMI PENDAFTARAN EVENT</strong></td>
        </tr>
        <tr>
            <td colspan="8" style="text-align: center;">Sistem Informasi Pendaftaran Event - EventGrids (UAS P. Web II)</td>
        </tr>
        <tr>
            <td colspan="8" style="text-align: center;">Mahasiswa: <strong>Ivan Hilmi Hersony (NIM: 251011701273)</strong></td>
        </tr>
        <tr>
            <td colspan="8"></td>
        </tr>
        <tr>
            <td colspan="3"><strong>Kriteria Filter Laporan:</strong></td>
            <td colspan="5"></td>
        </tr>
        <tr>
            <td colspan="2">Event Filter</td>
            <td colspan="6">: <?= htmlspecialchars($eventNameFilter) ?></td>
        </tr>
        <tr>
            <td colspan="2">Tanggal Filter</td>
            <td colspan="6">: <?= !empty($date) ? date('d-m-Y', strtotime($date)) : 'Semua Tanggal' ?></td>
        </tr>
        <tr>
            <td colspan="2">Status Pembayaran</td>
            <td colspan="6">: <?= !empty($payment_status) ? $payment_status : 'Semua Status' ?></td>
        </tr>
        <tr>
            <td colspan="2">Tanggal Cetak</td>
            <td colspan="6">: <?= date('d-m-Y H:i:s') ?></td>
        </tr>
        <tr>
            <td colspan="8"></td>
        </tr>
        <thead>
            <tr>
                <th style="background-color: #4F81BD; color: white;">No</th>
                <th style="background-color: #4F81BD; color: white;">NIM / ID Peserta</th>
                <th style="background-color: #4F81BD; color: white;">Nama Lengkap</th>
                <th style="background-color: #4F81BD; color: white;">Email</th>
                <th style="background-color: #4F81BD; color: white;">Nomor HP</th>
                <th style="background-color: #4F81BD; color: white;">Nama Event</th>
                <th style="background-color: #4F81BD; color: white;">Tanggal Daftar</th>
                <th style="background-color: #4F81BD; color: white;">Status Pembayaran</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($reportData)): ?>
                <tr>
                    <td colspan="8" style="text-align: center;">Tidak ada data pendaftaran yang ditemukan.</td>
                </tr>
            <?php else: 
                $no = 1;
                foreach ($reportData as $row):
            ?>
                <tr>
                    <td style="text-align: center;"><?= $no++ ?></td>
                    <td>'<?= htmlspecialchars($row['id']) ?></td> <!-- Tambahkan kutip agar NIM tidak berubah scientific/hilang nol -->
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td>'<?= htmlspecialchars($row['phone']) ?></td> <!-- Tambahkan kutip -->
                    <td><?= htmlspecialchars($row['event_name']) ?></td>
                    <td><?= date('d-m-Y', strtotime($row['registration_date'])) ?></td>
                    <td style="text-align: center;"><?= $row['payment_status'] ?></td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>

</body>
</html>
