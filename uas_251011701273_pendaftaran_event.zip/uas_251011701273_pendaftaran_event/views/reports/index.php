<?php
// Include header layout
include "views/layout/header.php";
?>

<div class="page-header">
    <div class="page-title">
        <h1>Laporan Pendaftaran Event</h1>
        <p>Filter data pendaftaran peserta, cetak dokumen resmi, dan ekspor laporan</p>
    </div>
    <div>
        <span class="badge badge-info" style="font-size: 14px; padding: 8px 16px;">
            <i class="fa-solid fa-file-export"></i> Ekspor Data Laporan
        </span>
    </div>
</div>

<!-- BAR FILTER LAPORAN -->
<div class="filter-search-bar">
    <h4 style="font-weight: 600; margin-bottom: 15px; font-size: 14px;"><i class="fa-solid fa-sliders"></i> Filter Parameter Laporan</h4>
    <form action="index.php" method="GET" class="filter-search-form">
        <input type="hidden" name="action" value="reports">
        
        <!-- Filter Event -->
        <div class="form-group" style="flex-grow: 2; min-width: 200px;">
            <label for="event_id" style="font-size: 12px; font-weight: 500;">Filter Berdasarkan Event</label>
            <select name="event_id" id="event_id" class="form-select">
                <option value="">Semua Event</option>
                <?php foreach ($events as $evt): ?>
                    <option value="<?= $evt['id'] ?>" <?= $event_id == $evt['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($evt['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Filter Tanggal -->
        <div class="form-group" style="flex-grow: 1; min-width: 150px;">
            <label for="date" style="font-size: 12px; font-weight: 500;">Filter Tanggal Daftar</label>
            <input type="date" name="date" id="date" class="form-input" value="<?= htmlspecialchars($date) ?>">
        </div>

        <!-- Filter Status Pembayaran -->
        <div class="form-group" style="flex-grow: 1; min-width: 150px;">
            <label for="payment_status" style="font-size: 12px; font-weight: 500;">Status Pembayaran</label>
            <select name="payment_status" id="payment_status" class="form-select">
                <option value="">Semua Status</option>
                <option value="Pending" <?= $payment_status === 'Pending' ? 'selected' : '' ?>>Pending</option>
                <option value="Paid" <?= $payment_status === 'Paid' ? 'selected' : '' ?>>Paid (Lunas)</option>
                <option value="Rejected" <?= $payment_status === 'Rejected' ? 'selected' : '' ?>>Rejected (Ditolak)</option>
            </select>
        </div>

        <!-- Buttons -->
        <div style="display: flex; align-items: flex-end; gap: 10px; margin-top: 20px;">
            <button type="submit" class="btn btn-secondary" style="height: 45px;">
                <i class="fa-solid fa-magnifying-glass"></i> Tampilkan
            </button>
            <a href="index.php?action=reports" class="btn btn-outline" style="height: 45px; display: flex; align-items: center;">
                <i class="fa-solid fa-rotate-left"></i> Reset
            </a>
        </div>
    </form>
</div>

<!-- TOMBOL EKSPOR & PREVIEW LAPORAN -->
<div class="card-container">
    <div class="card-title-bar">
        <h3><i class="fa-solid fa-table-list"></i> Preview Data Laporan (Hasil Pencarian)</h3>
        
        <!-- Action Buttons -->
        <div style="display: flex; gap: 10px;">
            <!-- Tombol Cetak / Print -->
            <a href="index.php?action=report_print&event_id=<?= $event_id ?>&date=<?= $date ?>&payment_status=<?= $payment_status ?>&format=print" 
               target="_blank" class="btn btn-outline" style="padding: 8px 16px; font-size: 13px;">
                <i class="fa-solid fa-print"></i> Cetak / Print
            </a>
            
            <!-- Tombol Export PDF -->
            <a href="index.php?action=report_print&event_id=<?= $event_id ?>&date=<?= $date ?>&payment_status=<?= $payment_status ?>&format=pdf" 
               target="_blank" class="btn btn-accent" style="padding: 8px 16px; font-size: 13px;">
                <i class="fa-solid fa-file-pdf"></i> Ekspor PDF
            </a>
            
            <!-- Tombol Export Excel -->
            <a href="index.php?action=report_excel&event_id=<?= $event_id ?>&date=<?= $date ?>&payment_status=<?= $payment_status ?>" 
               class="btn btn-primary" style="padding: 8px 16px; font-size: 13px;">
                <i class="fa-solid fa-file-excel"></i> Ekspor Excel
            </a>
        </div>
    </div>

    <!-- PREVIEW TABLE -->
    <div class="table-responsive">
        <table class="table-modern">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIM/ID</th>
                    <th>Nama Peserta</th>
                    <th>Email & HP</th>
                    <th>Event</th>
                    <th>Tgl Daftar</th>
                    <th>Pembayaran</th>
                    <th>Kehadiran</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reportData)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px 0;">
                            <i class="fa-regular fa-folder-open" style="font-size: 35px; margin-bottom: 10px; opacity: 0.5;"></i>
                            <p>Tidak ada data pendaftaran yang sesuai dengan filter.</p>
                        </td>
                    </tr>
                <?php else: 
                    $no = 1;
                    foreach ($reportData as $row):
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= htmlspecialchars($row['id']) ?></strong></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td>
                            <div><?= htmlspecialchars($row['email']) ?></div>
                            <span style="font-size: 11px; color: var(--text-muted);"><?= htmlspecialchars($row['phone']) ?></span>
                        </td>
                        <td><strong><?= htmlspecialchars($row['event_name']) ?></strong></td>
                        <td><?= date('d-m-Y', strtotime($row['registration_date'])) ?></td>
                        <td>
                            <?php if ($row['payment_status'] === 'Paid'): ?>
                                <span class="badge badge-success">Lunas</span>
                            <?php elseif ($row['payment_status'] === 'Pending'): ?>
                                <span class="badge badge-warning">Pending</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Ditolak</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($row['attendance_status'] === 'Present'): ?>
                                <span class="badge badge-success">Hadir</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Absen</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
// Include footer layout
include "views/layout/footer.php";
?>
