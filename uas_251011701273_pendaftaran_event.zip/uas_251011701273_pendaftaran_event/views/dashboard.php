<?php
// (("Include header layout"))
include "views/layout/header.php";

// (("Hitung persentase tinggi bar grafik secara dinamis"))
$max_count = 1;
foreach ($chartData as $dataPoint) {
    if ($dataPoint['count'] > $max_count) {
        $max_count = $dataPoint['count'];
    }
}
?>

<div class="page-header">
    <div class="page-title">
        <h1>Dashboard Organizer</h1>
        <p>Ringkasan statistik data pendaftaran event dan peserta terbaru</p>
    </div>
    <div>
        <span class="badge badge-info" style="font-size: 14px; padding: 8px 16px;">
            <i class="fa-solid fa-graduation-cap"></i> UAS - Ivan Hilmi Hersony
        </span>
    </div>
</div>

<!-- (("DASHBOARD TOP HIGHLIGHT SECTION")) -->
<div class="dashboard-top-section">
    <!-- Welcome Hero Card (Left) -->
    <div class="dashboard-welcome-hero">
        <div>
            <div class="academic-badge-split" style="background-color: rgba(255,191,0,0.15); color: var(--secondary); margin-bottom: 15px;">
                <i class="fa-solid fa-graduation-cap"></i> Lembar Kerja UAS Pemrograman Web II
            </div>
            <h2 style="font-size: 24px; font-weight: 700; margin-bottom: 10px;">Halo, <?= htmlspecialchars($user['name'] ?? 'Organizer') ?>!</h2>
            <p style="font-size: 13px; color: rgba(255,255,255,0.7); line-height: 1.6;">
                Selamat bekerja. Kelola data pendaftaran event, validasi berkas pembayaran peserta, dan hasilkan laporan ekspor cetak Universitas Pamulang dengan mudah melalui dashboard HilmiEvent.
            </p>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: flex-end; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 15px; margin-top: 20px; font-size: 11px; color: rgba(255,255,255,0.5);">
            <div>Dosen: <strong>Samso Supriyatna, S.Kom., M.Kom</strong></div>
            <div>NIM: <strong>251011701273</strong></div>
        </div>
    </div>

    <!-- Quick Stats Cards (Right) -->
    <div class="dashboard-quick-stats">
        <!-- Keuangan -->
        <div class="quick-stat-card gold-theme">
            <div class="stat-details">
                <span class="stat-title">Total Keuangan Masuk</span>
                <span class="stat-number">Rp <?= number_format($totalPayments, 0, ',', '.') ?></span>
            </div>
            <div class="stat-icon-wrapper">
                <i class="fa-solid fa-money-bill-wave"></i>
            </div>
        </div>
        <!-- Total Peserta -->
        <div class="quick-stat-card">
            <div class="stat-details">
                <span class="stat-title">Total Peserta Terdaftar</span>
                <span class="stat-number"><?= $totalParticipants ?> Orang</span>
            </div>
            <div class="stat-icon-wrapper" style="background-color: rgba(0,45,98,0.1); color: var(--primary);">
                <i class="fa-solid fa-users"></i>
            </div>
        </div>
    </div>
</div>

<!-- STAT CARDS (Daftar Event) -->
<div class="stats-grid">
    <!-- Card 1: Total Event -->
    <div class="stat-card">
        <div class="stat-info">
            <h3>Total Event</h3>
            <h2><?= $totalEvents ?></h2>
        </div>
        <div class="stat-icon primary" style="background-color: rgba(0,45,98,0.1); color: var(--primary);">
            <i class="fa-solid fa-calendar-days"></i>
        </div>
    </div>
    
    <!-- Card 2: Event Aktif -->
    <div class="stat-card">
        <div class="stat-info">
            <h3>Event Aktif</h3>
            <h2><?= $activeEvents ?></h2>
        </div>
        <div class="stat-icon success" style="background-color: rgba(16,185,129,0.1); color: var(--success);">
            <i class="fa-solid fa-square-poll-vertical"></i>
        </div>
    </div>

    <!-- Card 3: Event Selesai -->
    <div class="stat-card">
        <div class="stat-info">
            <h3>Event Selesai</h3>
            <h2><?= $completedEvents ?></h2>
        </div>
        <div class="stat-icon info" style="background-color: rgba(59,130,246,0.1); color: #3b82f6;">
            <i class="fa-solid fa-calendar-check"></i>
        </div>
    </div>
</div>

<!-- CHARTS AND LISTS GRID -->
<div class="section-grid">
    <!-- Left Column: Grafik Pendaftaran & Aktivitas Terbaru -->
    <div>
        <!-- Grafik Pendaftaran (Pure CSS) -->
        <div class="card-container">
            <div class="card-title-bar">
                <h3><i class="fa-solid fa-chart-simple"></i> Grafik Pendaftaran (7 Hari Terakhir)</h3>
                <span class="badge badge-info">Real-time</span>
            </div>
            
            <?php if (empty($chartData)): ?>
                <div style="text-align: center; padding: 40px 0; color: var(--text-muted);">
                    <i class="fa-solid fa-chart-line" style="font-size: 40px; margin-bottom: 10px; opacity: 0.5;"></i>
                    <p>Belum ada data pendaftaran dalam 7 hari terakhir.</p>
                </div>
            <?php else: ?>
                <div class="chart-box">
                    <?php foreach ($chartData as $dataPoint): 
                        $height = ($dataPoint['count'] / $max_count) * 80; // skala tinggi (maksimal 80%)
                        $dateFormatted = date('d M', strtotime($dataPoint['date']));
                    ?>
                        <div class="chart-bar-col">
                            <div class="chart-val"><?= $dataPoint['count'] ?></div>
                            <div class="chart-bar" style="height: <?= max($height, 5) ?>%;"></div>
                            <div class="chart-label"><?= $dateFormatted ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Aktivitas Terbaru (Timeline) -->
        <div class="card-container">
            <div class="card-title-bar">
                <h3><i class="fa-solid fa-clock-rotate-left"></i> Aktivitas Terbaru (Pendaftaran Peserta)</h3>
                <a href="index.php?action=participants" style="font-size: 12px; color: var(--primary); font-weight: 600;">Lihat Semua</a>
            </div>

            <?php if (empty($recentActivity)): ?>
                <p style="color: var(--text-muted); text-align: center; padding: 20px 0;">Belum ada aktivitas pendaftaran peserta.</p>
            <?php else: ?>
                <div class="timeline-activity">
                    <?php foreach ($recentActivity as $activity): 
                        $timeAgo = date('d-m-Y H:i', strtotime($activity['created_at']));
                    ?>
                        <div class="activity-item">
                            <div class="activity-content">
                                <h4>
                                    <strong><?= htmlspecialchars($activity['name']) ?></strong> mendaftar pada event 
                                    <span style="color: var(--primary);"><?= htmlspecialchars($activity['event_name']) ?></span>
                                </h4>
                                <p>
                                    NIM/ID: <?= htmlspecialchars($activity['id']) ?> | Status Bayar: 
                                    <?php if ($activity['payment_status'] === 'Paid'): ?>
                                        <span class="badge badge-success" style="padding: 2px 8px; font-size: 10px;">Lunas</span>
                                    <?php elseif ($activity['payment_status'] === 'Pending'): ?>
                                        <span class="badge badge-warning" style="padding: 2px 8px; font-size: 10px;">Pending</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger" style="padding: 2px 8px; font-size: 10px;">Ditolak</span>
                                    <?php endif; ?>
                                    | <i class="fa-regular fa-clock"></i> <?= $timeAgo ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Upcoming Events -->
    <div>
        <div class="card-container" style="height: calc(100% - 24px);">
            <div class="card-title-bar">
                <h3><i class="fa-solid fa-calendar-days"></i> Event Mendatang</h3>
                <a href="index.php?action=events" style="font-size: 12px; color: var(--primary); font-weight: 600;">Lihat Semua</a>
            </div>

            <?php if (empty($upcomingEvents)): ?>
                <p style="color: var(--text-muted); text-align: center; padding: 20px 0;">Tidak ada event aktif mendatang.</p>
            <?php else: ?>
                <div class="event-list-mini">
                    <?php foreach ($upcomingEvents as $evt): 
                        $day = date('d', strtotime($evt['date']));
                        $month = date('M', strtotime($evt['date']));
                        $time = date('H:i', strtotime($evt['time']));
                    ?>
                        <div class="event-item-mini">
                            <div class="event-date-box">
                                <span class="month"><?= $month ?></span>
                                <span class="day"><?= $day ?></span>
                            </div>
                            <div class="event-details-mini">
                                <h4><?= htmlspecialchars($evt['name']) ?></h4>
                                <p><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($evt['location']) ?></p>
                                <p><i class="fa-solid fa-clock"></i> Jam <?= $time ?> | Kuota: <?= $evt['quota'] ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// (("Include footer layout"))
include "views/layout/footer.php";
?>
