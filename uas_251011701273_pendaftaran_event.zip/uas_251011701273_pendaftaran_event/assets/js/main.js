 // (("UAS Pemrograman Web II - JavaScript File Nama: Ivan Hilmi Hersony NIM: 251011701273 Kustomisasi: Sidebar Toggles, Validasi Client-side, Konfirmasi Delete"))

document.addEventListener('DOMContentLoaded', function() {
    // (("1. COLLAPSIBLE SIDEBAR"))
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.querySelector('.sidebar-toggle-btn');
    
    if (sidebar && toggleBtn) {
        // (("Cek status sidebar dari localStorage"))
        const sidebarState = localStorage.getItem('sidebar-collapsed');
        if (sidebarState === 'true') {
            sidebar.classList.add('collapsed');
        }
        
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebar-collapsed', sidebar.classList.contains('collapsed'));
        });
    }

    // (("2. DYNAMIC CURRENT TIME (Live Update)"))
    const timeDisplay = document.getElementById('live-time');
    if (timeDisplay) {
        setInterval(() => {
            const now = new Date();
            timeDisplay.textContent = now.toLocaleDateString('id-ID', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            }) + ' | ' + now.toLocaleTimeString('id-ID');
        }, 1000);
    }

    // (("3. CONFIRM DELETE ACTION"))
    const deleteButtons = document.querySelectorAll('.btn-delete-confirm');
    deleteButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (!confirm('Apakah Anda yakin ingin menghapus data ini? Semua data relasi juga akan dihapus.')) {
                e.preventDefault();
            }
        });
    });

    // (("4. CLIENT SIDE FORM VALIDATIONS"))
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            let errorMessage = "";

            // (("Ambil seluruh input wajib"))
            const requiredFields = form.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                    errorMessage = "Semua field wajib diisi!";
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            // (("Validasi Email jika ada"))
            const emailField = form.querySelector('input[type="email"]');
            if (emailField && emailField.value.trim()) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(emailField.value.trim())) {
                    isValid = false;
                    emailField.classList.add('is-invalid');
                    errorMessage = "Format email tidak valid!";
                }
            }

            // (("Validasi Nomor HP (Hanya angka) jika ada"))
            const phoneField = form.querySelector('.validate-phone');
            if (phoneField && phoneField.value.trim()) {
                const phoneRegex = /^[0-9]+$/;
                if (!phoneRegex.test(phoneField.value.trim())) {
                    isValid = false;
                    phoneField.classList.add('is-invalid');
                    errorMessage = "Nomor HP hanya boleh berisi angka!";
                }
            }

            // (("Validasi File Upload (Ekstensi & Ukuran) jika ada"))
            const fileInput = form.querySelector('input[type="file"]');
            if (fileInput && fileInput.files.length > 0) {
                const file = fileInput.files[0];
                const allowedExtensions = /(\.jpg|\.jpeg|\.png|\.pdf)$/i;
                const maxSize = 2 * 1024 * 1024; // 2 MB

                if (!allowedExtensions.exec(file.name)) {
                    isValid = false;
                    fileInput.classList.add('is-invalid');
                    errorMessage = "Format file tidak diizinkan! Hanya JPG, PNG, dan PDF yang diperbolehkan.";
                } else if (file.size > maxSize) {
                    isValid = false;
                    fileInput.classList.add('is-invalid');
                    errorMessage = "Ukuran file terlalu besar! Maksimal ukuran file adalah 2 MB.";
                }
            }

            if (!isValid) {
                e.preventDefault();
                alert(errorMessage || "Mohon periksa kembali input formulir Anda.");
            }
        });
    });

    // (("5. RESTRICT INPUT ON NUMBER FIELDS"))
    const numberOnlyFields = document.querySelectorAll('.number-only');
    numberOnlyFields.forEach(field => {
        field.addEventListener('keypress', function(e) {
            if (e.which < 48 || e.which > 57) {
                e.preventDefault();
            }
        });
    });
});
