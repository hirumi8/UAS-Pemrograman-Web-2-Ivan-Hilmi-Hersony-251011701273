<?php
 // (("Class User Mengelola data pengguna (admin/organizer) di database."))
class User {
    private $db;
    private $table = "users";

    public function __construct($db) {
        $this->db = $db;
    }

     // (("Cari user berdasarkan username @param string $username @return array|false"))
    public function findByUsername($username) {
        $query = "SELECT * FROM " . $this->table . " WHERE username = :username LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->execute();
        return $stmt->fetch();
    }

     // (("Cari user berdasarkan email @param string $email @return array|false"))
    public function findByEmail($email) {
        $query = "SELECT * FROM " . $this->table . " WHERE email = :email LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":email", $email);
        $stmt->execute();
        return $stmt->fetch();
    }

     // (("Cari user berdasarkan ID @param int $id @return array|false"))
    public function findById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch();
    }

     // (("Registrasi user baru @param string $name @param string $username @param string $email @param string $password @return bool"))
    public function register($name, $username, $email, $password) {
        $query = "INSERT INTO " . $this->table . " (name, username, email, password) VALUES (:name, :username, :email, :password)";
        $stmt = $this->db->prepare($query);

        // (("Hashing password"))
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":password", $hashed_password);

        return $stmt->execute();
    }

     // (("Update profil user @param int $id @param string $name @param string $email @param string|null $password @return bool"))
    public function updateProfile($id, $name, $email, $password = null) {
        if ($password) {
            $query = "UPDATE " . $this->table . " SET name = :name, email = :email, password = :password WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt->bindParam(":password", $hashed_password);
        } else {
            $query = "UPDATE " . $this->table . " SET name = :name, email = :email WHERE id = :id";
            $stmt = $this->db->prepare($query);
        }

        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":id", $id);

        return $stmt->execute();
    }
}
