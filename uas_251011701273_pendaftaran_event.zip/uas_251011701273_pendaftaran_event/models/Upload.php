<?php
 // (("Class Upload Mengelola proses upload file bukti pembayaran, validasi ekstensi, ukuran file, pembuatan nama unik, dan penghapusan file lama."))
class Upload {
    private $targetDir;
    private $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf'];
    private $maxSize = 2097152; // 2 MB dalam bytes (2 * 1024 * 1024)

    public function __construct($targetDir = 'uploads/') {
        // (("Set target directory"))
        $this->targetDir = rtrim($targetDir, '/') . '/';
        
        // (("Buat folder uploads jika belum ada"))
        if (!file_exists($this->targetDir)) {
            mkdir($this->targetDir, 0777, true);
        }
    }

     // (("Memproses upload file @param array $fileVar Array $_FILES['input_name'] @param string $prefix Prefix untuk nama file unik @return string Nama file baru yang disimpan @throws Exception Jika validasi gagal"))
    public function uploadFile($fileVar, $prefix = 'bukti_') {
        // (("Validasi error upload bawaan PHP"))
        if ($fileVar['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("Gagal mengupload file. Error code: " . $fileVar['error']);
        }

        // (("Dapatkan informasi file"))
        $fileName = $fileVar['name'];
        $fileSize = $fileVar['size'];
        $tmpName = $fileVar['tmp_name'];

        // (("Dapatkan ekstensi file"))
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // (("Validasi Ekstensi"))
        if (!in_array($fileExt, $this->allowedExtensions)) {
            throw new Exception("Format file tidak diizinkan! Hanya JPG, PNG, dan PDF yang diperbolehkan.");
        }

        // (("Validasi Ukuran File (Maksimal 2 MB)"))
        if ($fileSize > $this->maxSize) {
            throw new Exception("Ukuran file terlalu besar! Maksimal ukuran file adalah 2 MB.");
        }

        // (("Buat nama file unik"))
        $newFileName = $prefix . uniqid() . '.' . $fileExt;
        $targetFilePath = $this->targetDir . $newFileName;

        // (("Pindahkan file ke target directory"))
        if (move_uploaded_file($tmpName, $targetFilePath)) {
            return $newFileName;
        } else {
            throw new Exception("Gagal memindahkan file ke direktori tujuan.");
        }
    }

     // (("Menghapus file lama jika ada @param string|null $filename Nama file yang akan dihapus @return bool True jika berhasil dihapus atau file tidak ada"))
    public function deleteFile($filename) {
        if (empty($filename)) {
            return true;
        }
        
        $filePath = $this->targetDir . $filename;
        if (file_exists($filePath)) {
            return unlink($filePath);
        }
        return true;
    }
}
