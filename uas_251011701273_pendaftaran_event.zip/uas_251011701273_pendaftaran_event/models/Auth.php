<?php
 // (("Class Auth Mengelola autentikasi pengguna, session, login, dan logout."))
class Auth {
    private $userModel;

    public function __construct($userModel) {
        $this->userModel = $userModel;
        // (("Memulai session jika belum dimulai"))
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }

     // (("Proses Login Pengguna @param string $username @param string $password @return array|string Array jika berhasil, String pesan error jika gagal"))
    public function login($username, $password) {
        // (("Validasi input"))
        if (empty($username) || empty($password)) {
            return "Username dan password wajib diisi!";
        }

        // (("Cari user"))
        $user = $this->userModel->findByUsername($username);

        if (!$user) {
            return "Username tidak terdaftar!";
        }

        // (("Verifikasi password"))
        if (password_verify($password, $user['password'])) {
            // (("Set Session"))
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['is_logged_in'] = true;
            return true;
        } else {
            return "Password salah!";
        }
    }

     // (("Proses Registrasi Pengguna Baru @param string $name @param string $username @param string $email @param string $password @param string $confirm_password @return bool|string True jika berhasil, String pesan error jika gagal"))
    public function register($name, $username, $email, $password, $confirm_password) {
        if (empty($name) || empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
            return "Semua kolom wajib diisi!";
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return "Format email tidak valid!";
        }

        if ($password !== $confirm_password) {
            return "Konfirmasi password tidak cocok!";
        }

        if (strlen($password) < 6) {
            return "Password minimal 6 karakter!";
        }

        // (("Cek apakah username sudah digunakan"))
        if ($this->userModel->findByUsername($username)) {
            return "Username sudah digunakan!";
        }

        // (("Cek apakah email sudah digunakan"))
        if ($this->userModel->findByEmail($email)) {
            return "Email sudah terdaftar!";
        }

        // (("Daftarkan user"))
        if ($this->userModel->register($name, $username, $email, $password)) {
            return true;
        }

        return "Terjadi kesalahan saat registrasi!";
    }

     // (("Proses Logout Pengguna"))
    public function logout() {
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }

     // (("Memeriksa apakah user sudah login Jika belum, redirect ke halaman login"))
    public function checkSession() {
        if (!$this->isLoggedIn()) {
            header("Location: index.php?action=login");
            exit();
        }
    }

     // (("Memeriksa status login @return bool"))
    public function isLoggedIn() {
        return isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true;
    }

     // (("Mendapatkan data user yang sedang login @return array|null"))
    public function getLoggedInUser() {
        if ($this->isLoggedIn()) {
            return [
                'id' => $_SESSION['user_id'],
                'name' => $_SESSION['name'],
                'username' => $_SESSION['username'],
                'email' => $_SESSION['email']
            ];
        }
        return null;
    }
}
