<?php
 // (("Class Participant Mengelola data peserta event di database."))
class Participant {
    private $db;
    private $table = "participants";

    public function __construct($db) {
        $this->db = $db;
    }

     // (("Ambil data peserta dengan filter, pencarian, pengurutan, dan paginasi"))
    public function getAll($search = '', $event_id = '', $payment_status = '', $sort_by = 'registration_date', $sort_order = 'DESC', $limit = 10, $offset = 0) {
        $query = "SELECT p.*, e.name as event_name, e.date as event_date 
                  FROM " . $this->table . " p 
                  JOIN events e ON p.event_id = e.id 
                  WHERE 1=1";
        $params = [];

        // (("Pencarian"))
        if (!empty($search)) {
            $query .= " AND (p.name LIKE :search1 OR p.email LIKE :search2 OR p.phone LIKE :search3 OR p.id LIKE :search4 OR e.name LIKE :search5)";
            $params[':search1'] = '%' . $search . '%';
            $params[':search2'] = '%' . $search . '%';
            $params[':search3'] = '%' . $search . '%';
            $params[':search4'] = '%' . $search . '%';
            $params[':search5'] = '%' . $search . '%';
        }

        // (("Filter Event"))
        if (!empty($event_id)) {
            $query .= " AND p.event_id = :event_id";
            $params[':event_id'] = $event_id;
        }

        // (("Filter Status Pembayaran"))
        if (!empty($payment_status)) {
            $query .= " AND p.payment_status = :payment_status";
            $params[':payment_status'] = $payment_status;
        }

        // (("Pengurutan"))
        $allowed_sort_cols = ['id', 'name', 'email', 'registration_date', 'payment_status', 'attendance_status', 'event_name'];
        if (!in_array($sort_by, $allowed_sort_cols)) {
            $sort_by = 'registration_date';
        }
        
        $sort_order = strtoupper($sort_order) === 'ASC' ? 'ASC' : 'DESC';
        
        // (("Atasi sorting untuk join table alias"))
        $sort_column = $sort_by;
        if ($sort_by === 'event_name') {
            $sort_column = 'e.name';
        } else {
            $sort_column = 'p.' . $sort_by;
        }

        $query .= " ORDER BY " . $sort_column . " " . $sort_order;
        $query .= " LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($query);

        // (("Bind parameters"))
        foreach ($params as $key => &$val) {
            $stmt->bindParam($key, $val);
        }
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int) $offset, PDO::PARAM_INT);

        $stmt->execute();
        return $stmt->fetchAll();
    }

     // (("Hitung total data peserta untuk paginasi"))
    public function countAll($search = '', $event_id = '', $payment_status = '') {
        $query = "SELECT COUNT(*) as total 
                  FROM " . $this->table . " p 
                  JOIN events e ON p.event_id = e.id 
                  WHERE 1=1";
        $params = [];

        if (!empty($search)) {
            $query .= " AND (p.name LIKE :search1 OR p.email LIKE :search2 OR p.phone LIKE :search3 OR p.id LIKE :search4 OR e.name LIKE :search5)";
            $params[':search1'] = '%' . $search . '%';
            $params[':search2'] = '%' . $search . '%';
            $params[':search3'] = '%' . $search . '%';
            $params[':search4'] = '%' . $search . '%';
            $params[':search5'] = '%' . $search . '%';
        }

        if (!empty($event_id)) {
            $query .= " AND p.event_id = :event_id";
            $params[':event_id'] = $event_id;
        }

        if (!empty($payment_status)) {
            $query .= " AND p.payment_status = :payment_status";
            $params[':payment_status'] = $payment_status;
        }

        $stmt = $this->db->prepare($query);
        foreach ($params as $key => &$val) {
            $stmt->bindParam($key, $val);
        }
        $stmt->execute();
        $result = $stmt->fetch();
        return $result ? $result['total'] : 0;
    }

     // (("Cari detail peserta berdasarkan ID"))
    public function findById($id) {
        $query = "SELECT p.*, e.name as event_name, e.location as event_location, e.date as event_date, e.time as event_time 
                  FROM " . $this->table . " p 
                  JOIN events e ON p.event_id = e.id 
                  WHERE p.id = :id LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch();
    }

     // (("Cek apakah ID Peserta sudah digunakan"))
    public function isIdExists($id) {
        $query = "SELECT COUNT(*) as total FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        $res = $stmt->fetch();
        return $res && $res['total'] > 0;
    }

     // (("Tambah peserta baru"))
    public function create($id, $name, $email, $phone, $gender, $event_id, $registration_date, $payment_status, $payment_proof, $attendance_status) {
        $query = "INSERT INTO " . $this->table . " 
                  (id, name, email, phone, gender, event_id, registration_date, payment_status, payment_proof, attendance_status) 
                  VALUES (:id, :name, :email, :phone, :gender, :event_id, :registration_date, :payment_status, :payment_proof, :attendance_status)";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":phone", $phone);
        $stmt->bindParam(":gender", $gender);
        $stmt->bindParam(":event_id", $event_id);
        $stmt->bindParam(":registration_date", $registration_date);
        $stmt->bindParam(":payment_status", $payment_status);
        $stmt->bindParam(":payment_proof", $payment_proof);
        $stmt->bindParam(":attendance_status", $attendance_status);

        return $stmt->execute();
    }

     // (("Update data peserta"))
    public function update($id, $name, $email, $phone, $gender, $event_id, $registration_date, $payment_status, $payment_proof, $attendance_status) {
        $query = "UPDATE " . $this->table . " SET 
                  name = :name, 
                  email = :email, 
                  phone = :phone, 
                  gender = :gender, 
                  event_id = :event_id, 
                  registration_date = :registration_date, 
                  payment_status = :payment_status, 
                  payment_proof = :payment_proof, 
                  attendance_status = :attendance_status 
                  WHERE id = :id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":phone", $phone);
        $stmt->bindParam(":gender", $gender);
        $stmt->bindParam(":event_id", $event_id);
        $stmt->bindParam(":registration_date", $registration_date);
        $stmt->bindParam(":payment_status", $payment_status);
        $stmt->bindParam(":payment_proof", $payment_proof);
        $stmt->bindParam(":attendance_status", $attendance_status);

        return $stmt->execute();
    }

     // (("Hapus data peserta"))
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }

     // (("Mengubah bukti pembayaran secara langsung"))
    public function updatePaymentProof($id, $filename, $payment_status = 'Pending') {
        $query = "UPDATE " . $this->table . " SET payment_proof = :payment_proof, payment_status = :payment_status WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->bindParam(":payment_proof", $filename);
        $stmt->bindParam(":payment_status", $payment_status);
        return $stmt->execute();
    }

     // (("Hitung total peserta untuk dashboard"))
    public function getTotalParticipants() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table;
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $res = $stmt->fetch();
        return $res ? $res['total'] : 0;
    }

     // (("Hitung total dana pembayaran masuk (Lunas / Paid) secara dinamis dari harga event"))
    public function getTotalPayments() {
        $query = "SELECT SUM(e.price) as total 
                  FROM " . $this->table . " p 
                  JOIN events e ON p.event_id = e.id 
                  WHERE p.payment_status = 'Paid'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $res = $stmt->fetch();
        return $res && $res['total'] !== null ? (int)$res['total'] : 0;
    }

     // (("Mengambil 5 aktivitas terbaru (pendaftaran peserta terbaru)"))
    public function getRecentActivity($limit = 5) {
        $query = "SELECT p.*, e.name as event_name 
                  FROM " . $this->table . " p 
                  JOIN events e ON p.event_id = e.id 
                  ORDER BY p.created_at DESC 
                  LIMIT :limit";
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

     // (("Mendapatkan data grafik pendaftaran 7 hari terakhir"))
    public function getRegistrationChartData() {
        $query = "SELECT registration_date as date, COUNT(*) as count 
                  FROM " . $this->table . " 
                  WHERE registration_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
                  GROUP BY registration_date 
                  ORDER BY registration_date ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
