<?php
 // (("Class Event Mengelola data event/kegiatan di database."))
class Event {
    private $db;
    private $table = "events";

    public function __construct($db) {
        $this->db = $db;
    }

     // (("Mengambil list event dengan filter, pencarian, pengurutan, dan paginasi"))
    public function getAll($search = '', $status = '', $sort_by = 'date', $sort_order = 'ASC', $limit = 10, $offset = 0) {
        $query = "SELECT * FROM " . $this->table . " WHERE 1=1";
        $params = [];

        // (("Pencarian"))
        if (!empty($search)) {
            $query .= " AND (name LIKE :search1 OR location LIKE :search2)";
            $params[':search1'] = '%' . $search . '%';
            $params[':search2'] = '%' . $search . '%';
        }

        // (("Filter Status"))
        if (!empty($status)) {
            $query .= " AND status = :status";
            $params[':status'] = $status;
        }

        // (("Pengurutan"))
        // (("Validasi kolom pengurutan untuk menghindari SQL Injection"))
        $allowed_sort_cols = ['name', 'location', 'date', 'quota', 'price', 'status'];
        if (!in_array($sort_by, $allowed_sort_cols)) {
            $sort_by = 'date';
        }
        $sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
        $query .= " ORDER BY " . $sort_by . " " . $sort_order;

        // (("Paginasi"))
        $query .= " LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($query);

        // (("Bind parameters"))
        foreach ($params as $key => &$val) {
            $stmt->bindParam($key, $val);
        }
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int) $offset, PDO::PARAM_INT);

        $stmt->execute();
        return $stmt->fetchAll();
    }

     // (("Hitung total data event untuk paginasi"))
    public function countAll($search = '', $status = '') {
        $query = "SELECT COUNT(*) as total FROM " . $this->table . " WHERE 1=1";
        $params = [];

        if (!empty($search)) {
            $query .= " AND (name LIKE :search1 OR location LIKE :search2)";
            $params[':search1'] = '%' . $search . '%';
            $params[':search2'] = '%' . $search . '%';
        }

        if (!empty($status)) {
            $query .= " AND status = :status";
            $params[':status'] = $status;
        }

        $stmt = $this->db->prepare($query);
        foreach ($params as $key => &$val) {
            $stmt->bindParam($key, $val);
        }
        $stmt->execute();
        $result = $stmt->fetch();
        return $result ? $result['total'] : 0;
    }

     // (("Ambil detail Event berdasarkan ID"))
    public function findById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch();
    }

     // (("Tambah Event baru"))
    public function create($name, $location, $date, $time, $quota, $price, $status) {
        $query = "INSERT INTO " . $this->table . " (name, location, date, time, quota, price, status) VALUES (:name, :location, :date, :time, :quota, :price, :status)";
        $stmt = $this->db->prepare($query);

        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":location", $location);
        $stmt->bindParam(":date", $date);
        $stmt->bindParam(":time", $time);
        $stmt->bindParam(":quota", $quota);
        $stmt->bindParam(":price", $price);
        $stmt->bindParam(":status", $status);

        return $stmt->execute();
    }

     // (("Update data Event"))
    public function update($id, $name, $location, $date, $time, $quota, $price, $status) {
        $query = "UPDATE " . $this->table . " SET name = :name, location = :location, date = :date, time = :time, quota = :quota, price = :price, status = :status WHERE id = :id";
        $stmt = $this->db->prepare($query);

        $stmt->bindParam(":id", $id);
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":location", $location);
        $stmt->bindParam(":date", $date);
        $stmt->bindParam(":time", $time);
        $stmt->bindParam(":quota", $quota);
        $stmt->bindParam(":price", $price);
        $stmt->bindParam(":status", $status);

        return $stmt->execute();
    }

     // (("Hapus Event"))
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }

     // (("Fungsi helper untuk statistik Dashboard"))
    public function getTotalEvents() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table;
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $res = $stmt->fetch();
        return $res ? $res['total'] : 0;
    }

    public function getActiveEventCount() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table . " WHERE status = 'Active'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $res = $stmt->fetch();
        return $res ? $res['total'] : 0;
    }

    public function getCompletedEventCount() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table . " WHERE status = 'Completed'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $res = $stmt->fetch();
        return $res ? $res['total'] : 0;
    }

    public function getUpcomingEvents($limit = 5) {
        $query = "SELECT * FROM " . $this->table . " WHERE date >= CURDATE() AND status = 'Active' ORDER BY date ASC, time ASC LIMIT :limit";
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

     // (("Mengambil list event tanpa paginasi (untuk dropdown di pendaftaran peserta)"))
    public function getDropdownList() {
        $query = "SELECT id, name, status, quota FROM " . $this->table . " ORDER BY name ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
