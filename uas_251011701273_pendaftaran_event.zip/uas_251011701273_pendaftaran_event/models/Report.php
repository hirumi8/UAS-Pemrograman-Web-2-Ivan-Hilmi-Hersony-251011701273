<?php
 // (("Class Report Mengelola pengambilan data berfilter untuk laporan PDF dan Excel."))
class Report {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

     // (("Ambil data pendaftaran peserta dengan filter tertentu @param string $event_id Filter ID Event @param string $date Filter tanggal pendaftaran @param string $payment_status Filter status pembayaran @return array Data peserta"))
    public function getFilteredData($event_id = '', $date = '', $payment_status = '') {
        $query = "SELECT p.*, e.name as event_name, e.location as event_location, e.date as event_date, e.time as event_time 
                  FROM participants p 
                  JOIN events e ON p.event_id = e.id 
                  WHERE 1=1";
        $params = [];

        // (("Filter berdasarkan Event"))
        if (!empty($event_id)) {
            $query .= " AND p.event_id = :event_id";
            $params[':event_id'] = $event_id;
        }

        // (("Filter berdasarkan Tanggal Daftar"))
        if (!empty($date)) {
            $query .= " AND p.registration_date = :registration_date";
            $params[':registration_date'] = $date;
        }

        // (("Filter berdasarkan Status Pembayaran"))
        if (!empty($payment_status)) {
            $query .= " AND p.payment_status = :payment_status";
            $params[':payment_status'] = $payment_status;
        }

        $query .= " ORDER BY p.registration_date DESC, p.id ASC";

        $stmt = $this->db->prepare($query);

        // (("Bind parameters"))
        foreach ($params as $key => &$val) {
            $stmt->bindParam($key, $val);
        }

        $stmt->execute();
        return $stmt->fetchAll();
    }
}
