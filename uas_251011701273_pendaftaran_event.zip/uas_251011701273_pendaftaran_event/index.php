<?php
 // (("UAS Pemrograman Web II - Sistem Informasi Pendaftaran Event Nama: Ivan Hilmi Hersony NIM: 251011701273 Digit terakhir NIM: 3 File: index.php (Front Controller / Router Utama)"))

// (("Aktifkan reporting error untuk mempermudah debugging (Development Mode)"))
error_reporting(E_ALL);
ini_set('display_errors', 1);

// (("Set timezone lokal Indonesia"))
date_default_timezone_set('Asia/Jakarta');

// (("Memulai session jika belum ada"))
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// (("1. Sertakan konfigurasi database"))
require_once "config/Database.php";

// (("2. Sertakan seluruh model (OOP) secara manual sesuai struktur tugas"))
require_once "models/User.php";
require_once "models/Auth.php";
require_once "models/Event.php";
require_once "models/Participant.php";
require_once "models/Report.php";
require_once "models/Upload.php";

// (("3. Sertakan seluruh controller"))
require_once "controllers/AuthController.php";
require_once "controllers/DashboardController.php";
require_once "controllers/EventController.php";
require_once "controllers/ParticipantController.php";
require_once "controllers/ReportController.php";

// (("4. Inisialisasi Database dan Koneksi"))
$database = new Database();
$db = $database->getConnection();

// (("5. Inisialisasi Model"))
$userModel = new User($db);
$authModel = new Auth($userModel);
$eventModel = new Event($db);
$participantModel = new Participant($db);
$reportModel = new Report($db);
$uploadHelper = new Upload('uploads/');

// (("6. Inisialisasi Controller"))
$authController = new AuthController($authModel, $userModel);
$dashboardController = new DashboardController($authModel, $eventModel, $participantModel);
$eventController = new EventController($authModel, $eventModel);
$participantController = new ParticipantController($authModel, $participantModel, $eventModel, $uploadHelper);
$reportController = new ReportController($authModel, $reportModel, $eventModel);

// (("7. Routing Sederhana berdasarkan parameter 'action"))
$action = $_GET['action'] ?? 'dashboard';

switch ($action) {
    // (("Autentikasi"))
    case 'login':
        $authController->login();
        break;
        
    case 'register':
        $authController->register();
        break;
        
    case 'logout':
        $authController->logout();
        break;
        
    case 'profile':
        $authController->profile();
        break;

    // (("Dashboard"))
    case 'dashboard':
        $dashboardController->index();
        break;

    // (("CRUD Event"))
    case 'events':
        $eventController->index();
        break;
        
    case 'event_add':
        $eventController->add();
        break;
        
    case 'event_edit':
        $eventController->edit();
        break;
        
    case 'event_delete':
        $eventController->delete();
        break;

    // (("CRUD Peserta / Participant"))
    case 'participants':
        $participantController->index();
        break;
        
    case 'participant_detail':
        $participantController->detail();
        break;
        
    case 'participant_add':
        $participantController->add();
        break;
        
    case 'participant_edit':
        $participantController->edit();
        break;
        
    case 'participant_delete':
        $participantController->delete();
        break;
        
    case 'upload_payment':
        $participantController->upload_payment();
        break;

    // (("Laporan / Reports"))
    case 'reports':
        $reportController->index();
        break;
        
    case 'report_print':
        $reportController->printReport();
        break;
        
    case 'report_excel':
        $reportController->exportExcel();
        break;

    // (("Halaman default/salah route akan diarahkan ke dashboard"))
    default:
        header("Location: index.php?action=dashboard");
        exit();
}
